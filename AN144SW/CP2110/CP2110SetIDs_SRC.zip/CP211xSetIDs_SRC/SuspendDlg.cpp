// SuspendDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SetIDs.h"
#include "SuspendDlg.h"
#include "SLABCP2110.h"

// CSuspendDlg dialog

IMPLEMENT_DYNAMIC(CSuspendDlg, CDialog)

CSuspendDlg::CSuspendDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSuspendDlg::IDD, pParent)
{
	m_suspendMode	= 0x0000;
	m_suspendValue	= 0x0000;
}

CSuspendDlg::~CSuspendDlg()
{
}

void CSuspendDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CSuspendDlg, CDialog)
	ON_BN_CLICKED(IDOK, &CSuspendDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CSuspendDlg::OnBnClickedCancel)
	ON_BN_CLICKED(IDC_CHECK_GPIO_0_MODE, &CSuspendDlg::OnBnClickedCheckMode)
	ON_BN_CLICKED(IDC_CHECK_GPIO_1_MODE, &CSuspendDlg::OnBnClickedCheckMode)
	ON_BN_CLICKED(IDC_CHECK_GPIO_2_MODE, &CSuspendDlg::OnBnClickedCheckMode)
	ON_BN_CLICKED(IDC_CHECK_GPIO_3_MODE, &CSuspendDlg::OnBnClickedCheckMode)
	ON_BN_CLICKED(IDC_CHECK_GPIO_4_MODE, &CSuspendDlg::OnBnClickedCheckMode)
	ON_BN_CLICKED(IDC_CHECK_GPIO_5_MODE, &CSuspendDlg::OnBnClickedCheckMode)
	ON_BN_CLICKED(IDC_CHECK_GPIO_6_MODE, &CSuspendDlg::OnBnClickedCheckMode)
	ON_BN_CLICKED(IDC_CHECK_GPIO_7_MODE, &CSuspendDlg::OnBnClickedCheckMode)
	ON_BN_CLICKED(IDC_CHECK_GPIO_8_MODE, &CSuspendDlg::OnBnClickedCheckMode)
	ON_BN_CLICKED(IDC_CHECK_GPIO_9_MODE, &CSuspendDlg::OnBnClickedCheckMode)
	ON_BN_CLICKED(IDC_CHECK_TX_MODE, &CSuspendDlg::OnBnClickedCheckMode)
	ON_BN_CLICKED(IDC_CHECK_RX_MODE, &CSuspendDlg::OnBnClickedCheckMode)
	ON_BN_CLICKED(IDC_CHECK_SUSPEND_MODE, &CSuspendDlg::OnBnClickedCheckMode)
	ON_BN_CLICKED(IDC_CHECK_SUSPEND_BAR_MODE, &CSuspendDlg::OnBnClickedCheckMode)
	ON_BN_CLICKED(IDC_CHECK_GPIO_0_VALUE, &CSuspendDlg::OnBnClickedCheckValue)
	ON_BN_CLICKED(IDC_CHECK_GPIO_1_VALUE, &CSuspendDlg::OnBnClickedCheckValue)
	ON_BN_CLICKED(IDC_CHECK_GPIO_2_VALUE, &CSuspendDlg::OnBnClickedCheckValue)
	ON_BN_CLICKED(IDC_CHECK_GPIO_3_VALUE, &CSuspendDlg::OnBnClickedCheckValue)
	ON_BN_CLICKED(IDC_CHECK_GPIO_4_VALUE, &CSuspendDlg::OnBnClickedCheckValue)
	ON_BN_CLICKED(IDC_CHECK_GPIO_5_VALUE, &CSuspendDlg::OnBnClickedCheckValue)
	ON_BN_CLICKED(IDC_CHECK_GPIO_6_VALUE, &CSuspendDlg::OnBnClickedCheckValue)
	ON_BN_CLICKED(IDC_CHECK_GPIO_7_VALUE, &CSuspendDlg::OnBnClickedCheckValue)
	ON_BN_CLICKED(IDC_CHECK_GPIO_8_VALUE, &CSuspendDlg::OnBnClickedCheckValue)
	ON_BN_CLICKED(IDC_CHECK_GPIO_9_VALUE, &CSuspendDlg::OnBnClickedCheckValue)
END_MESSAGE_MAP()


// CSuspendDlg message handlers

void CSuspendDlg::OnBnClickedOk()
{
	m_suspendMode	= 0x0000;

	// TX, RX, Suspend, /Suspend latch values are ignored
	// Set them to their actual values here
	m_suspendValue	= HID_UART_MASK_SUSPEND | HID_UART_MASK_RX | HID_UART_MASK_TX;

	// Update suspend mask value
	if (IsDlgButtonChecked(IDC_CHECK_GPIO_0_MODE))			m_suspendMode |= HID_UART_MASK_GPIO_0_CLK;
	if (IsDlgButtonChecked(IDC_CHECK_GPIO_1_MODE))			m_suspendMode |= HID_UART_MASK_GPIO_1_RTS;
	if (IsDlgButtonChecked(IDC_CHECK_GPIO_2_MODE))			m_suspendMode |= HID_UART_MASK_GPIO_2_CTS;
	if (IsDlgButtonChecked(IDC_CHECK_GPIO_3_MODE))			m_suspendMode |= HID_UART_MASK_GPIO_3_RS485;
	if (IsDlgButtonChecked(IDC_CHECK_GPIO_4_MODE))			m_suspendMode |= HID_UART_MASK_GPIO_4_TX_TOGGLE;
	if (IsDlgButtonChecked(IDC_CHECK_GPIO_5_MODE))			m_suspendMode |= HID_UART_MASK_GPIO_5_RX_TOGGLE;
	if (IsDlgButtonChecked(IDC_CHECK_GPIO_6_MODE))			m_suspendMode |= HID_UART_MASK_GPIO_6;
	if (IsDlgButtonChecked(IDC_CHECK_GPIO_7_MODE))			m_suspendMode |= HID_UART_MASK_GPIO_7;
	if (IsDlgButtonChecked(IDC_CHECK_GPIO_8_MODE))			m_suspendMode |= HID_UART_MASK_GPIO_8;
	if (IsDlgButtonChecked(IDC_CHECK_GPIO_9_MODE))			m_suspendMode |= HID_UART_MASK_GPIO_9;
	if (IsDlgButtonChecked(IDC_CHECK_TX_MODE))				m_suspendMode |= HID_UART_MASK_TX;
	if (IsDlgButtonChecked(IDC_CHECK_RX_MODE))				m_suspendMode |= HID_UART_MASK_RX;
	if (IsDlgButtonChecked(IDC_CHECK_SUSPEND_MODE))			m_suspendMode |= HID_UART_MASK_SUSPEND;
	if (IsDlgButtonChecked(IDC_CHECK_SUSPEND_BAR_MODE))		m_suspendMode |= HID_UART_MASK_SUSPEND_BAR;

	// Update suspend latch value
	if (IsDlgButtonChecked(IDC_CHECK_GPIO_0_VALUE))			m_suspendValue |= HID_UART_MASK_GPIO_0_CLK;
	if (IsDlgButtonChecked(IDC_CHECK_GPIO_1_VALUE))			m_suspendValue |= HID_UART_MASK_GPIO_1_RTS;
	if (IsDlgButtonChecked(IDC_CHECK_GPIO_2_VALUE))			m_suspendValue |= HID_UART_MASK_GPIO_2_CTS;
	if (IsDlgButtonChecked(IDC_CHECK_GPIO_3_VALUE))			m_suspendValue |= HID_UART_MASK_GPIO_3_RS485;
	if (IsDlgButtonChecked(IDC_CHECK_GPIO_4_VALUE))			m_suspendValue |= HID_UART_MASK_GPIO_4_TX_TOGGLE;
	if (IsDlgButtonChecked(IDC_CHECK_GPIO_5_VALUE))			m_suspendValue |= HID_UART_MASK_GPIO_5_RX_TOGGLE;
	if (IsDlgButtonChecked(IDC_CHECK_GPIO_6_VALUE))			m_suspendValue |= HID_UART_MASK_GPIO_6;
	if (IsDlgButtonChecked(IDC_CHECK_GPIO_7_VALUE))			m_suspendValue |= HID_UART_MASK_GPIO_7;
	if (IsDlgButtonChecked(IDC_CHECK_GPIO_8_VALUE))			m_suspendValue |= HID_UART_MASK_GPIO_8;
	if (IsDlgButtonChecked(IDC_CHECK_GPIO_9_VALUE))			m_suspendValue |= HID_UART_MASK_GPIO_9;

	OnOK();
}

void CSuspendDlg::OnBnClickedCancel()
{
	OnCancel();
}

void CSuspendDlg::CheckMode(int nID)
{
	if (IsDlgButtonChecked(nID))
	{
		SetDlgItemText(nID, _T("Push Pull"));
	}
	else
	{
		SetDlgItemText(nID, _T("Open Drain"));
	}
}

void CSuspendDlg::CheckValue(int nID)
{
	if (IsDlgButtonChecked(nID))
	{
		SetDlgItemText(nID, _T("1"));
	}
	else
	{
		SetDlgItemText(nID, _T("0"));
	}
}

void CSuspendDlg::OnBnClickedCheckMode()
{
	if(GetCurrentMessage()->message == WM_COMMAND)
	{
		int nID = (int)GetCurrentMessage()->wParam;

		CheckMode(nID);
	}
}

void CSuspendDlg::OnBnClickedCheckValue()
{
	if(GetCurrentMessage()->message == WM_COMMAND)
	{
		int nID = (int)GetCurrentMessage()->wParam;

		CheckValue(nID);
	}
}

BOOL CSuspendDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Init latch mode checkboxes
	CheckDlgButton(IDC_CHECK_GPIO_0_MODE,		(m_suspendMode & HID_UART_MASK_GPIO_0_CLK) != 0);			CheckMode(IDC_CHECK_GPIO_0_MODE);
	CheckDlgButton(IDC_CHECK_GPIO_1_MODE,		(m_suspendMode & HID_UART_MASK_GPIO_1_RTS) != 0);			CheckMode(IDC_CHECK_GPIO_1_MODE);
	CheckDlgButton(IDC_CHECK_GPIO_2_MODE,		(m_suspendMode & HID_UART_MASK_GPIO_2_CTS) != 0);			CheckMode(IDC_CHECK_GPIO_2_MODE);
	CheckDlgButton(IDC_CHECK_GPIO_3_MODE,		(m_suspendMode & HID_UART_MASK_GPIO_3_RS485) != 0);			CheckMode(IDC_CHECK_GPIO_3_MODE);
	CheckDlgButton(IDC_CHECK_GPIO_4_MODE,		(m_suspendMode & HID_UART_MASK_GPIO_4_TX_TOGGLE) != 0);		CheckMode(IDC_CHECK_GPIO_4_MODE);
	CheckDlgButton(IDC_CHECK_GPIO_5_MODE,		(m_suspendMode & HID_UART_MASK_GPIO_5_RX_TOGGLE) != 0);		CheckMode(IDC_CHECK_GPIO_5_MODE);
	CheckDlgButton(IDC_CHECK_GPIO_6_MODE,		(m_suspendMode & HID_UART_MASK_GPIO_6) != 0);				CheckMode(IDC_CHECK_GPIO_6_MODE);
	CheckDlgButton(IDC_CHECK_GPIO_7_MODE,		(m_suspendMode & HID_UART_MASK_GPIO_7) != 0);				CheckMode(IDC_CHECK_GPIO_7_MODE);
	CheckDlgButton(IDC_CHECK_GPIO_8_MODE,		(m_suspendMode & HID_UART_MASK_GPIO_8) != 0);				CheckMode(IDC_CHECK_GPIO_8_MODE);
	CheckDlgButton(IDC_CHECK_GPIO_9_MODE,		(m_suspendMode & HID_UART_MASK_GPIO_9) != 0);				CheckMode(IDC_CHECK_GPIO_9_MODE);
	CheckDlgButton(IDC_CHECK_TX_MODE,			(m_suspendMode & HID_UART_MASK_TX) != 0);					CheckMode(IDC_CHECK_TX_MODE);
	CheckDlgButton(IDC_CHECK_RX_MODE,			(m_suspendMode & HID_UART_MASK_RX) != 0);					CheckMode(IDC_CHECK_RX_MODE);
	CheckDlgButton(IDC_CHECK_SUSPEND_MODE,		(m_suspendMode & HID_UART_MASK_SUSPEND) != 0);				CheckMode(IDC_CHECK_SUSPEND_MODE);
	CheckDlgButton(IDC_CHECK_SUSPEND_BAR_MODE,	(m_suspendMode & HID_UART_MASK_SUSPEND_BAR) != 0);			CheckMode(IDC_CHECK_SUSPEND_BAR_MODE);

	// Init latch value checkboxes
	CheckDlgButton(IDC_CHECK_GPIO_0_VALUE,		(m_suspendValue & HID_UART_MASK_GPIO_0_CLK) != 0);			CheckValue(IDC_CHECK_GPIO_0_VALUE);
	CheckDlgButton(IDC_CHECK_GPIO_1_VALUE,		(m_suspendValue & HID_UART_MASK_GPIO_1_RTS) != 0);			CheckValue(IDC_CHECK_GPIO_1_VALUE);
	CheckDlgButton(IDC_CHECK_GPIO_2_VALUE,		(m_suspendValue & HID_UART_MASK_GPIO_2_CTS) != 0);			CheckValue(IDC_CHECK_GPIO_2_VALUE);
	CheckDlgButton(IDC_CHECK_GPIO_3_VALUE,		(m_suspendValue & HID_UART_MASK_GPIO_3_RS485) != 0);		CheckValue(IDC_CHECK_GPIO_3_VALUE);
	CheckDlgButton(IDC_CHECK_GPIO_4_VALUE,		(m_suspendValue & HID_UART_MASK_GPIO_4_TX_TOGGLE) != 0);	CheckValue(IDC_CHECK_GPIO_4_VALUE);
	CheckDlgButton(IDC_CHECK_GPIO_5_VALUE,		(m_suspendValue & HID_UART_MASK_GPIO_5_RX_TOGGLE) != 0);	CheckValue(IDC_CHECK_GPIO_5_VALUE);
	CheckDlgButton(IDC_CHECK_GPIO_6_VALUE,		(m_suspendValue & HID_UART_MASK_GPIO_6) != 0);				CheckValue(IDC_CHECK_GPIO_6_VALUE);
	CheckDlgButton(IDC_CHECK_GPIO_7_VALUE,		(m_suspendValue & HID_UART_MASK_GPIO_7) != 0);				CheckValue(IDC_CHECK_GPIO_7_VALUE);
	CheckDlgButton(IDC_CHECK_GPIO_8_VALUE,		(m_suspendValue & HID_UART_MASK_GPIO_8) != 0);				CheckValue(IDC_CHECK_GPIO_8_VALUE);
	CheckDlgButton(IDC_CHECK_GPIO_9_VALUE,		(m_suspendValue & HID_UART_MASK_GPIO_9) != 0);				CheckValue(IDC_CHECK_GPIO_9_VALUE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
