/////////////////////////////////////////////////////////////////////////////
// SetIDsDlg.cpp : implementation file
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
// Includes
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SetIDs.h"
#include "SetIDsDlg.h"
#include "CustomDDX.h"
#include "SuspendDlg.h"
#include <vector>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
// Namespaces
/////////////////////////////////////////////////////////////////////////////

using namespace std;

/////////////////////////////////////////////////////////////////////////////
// Linker library inputs
/////////////////////////////////////////////////////////////////////////////

#pragma comment(lib, "SLABHIDtoUART.lib")

/////////////////////////////////////////////////////////////////////////////
// Static Global Variables
/////////////////////////////////////////////////////////////////////////////

struct UnlistedDevice
{
	WORD vid;
	WORD pid;
};

// Devices with these VID/PID combinations
// will not be listed in the device list
static UnlistedDevice UnlistedDevices[] = 
{
	{0x10C4, 0x8044},	// USB Debug Adapter
	{0x10C4, 0x8253}	// ToolStick
};

/////////////////////////////////////////////////////////////////////////////
// Static Function Prototypes
/////////////////////////////////////////////////////////////////////////////

// Return TRUE if the specified VID/PID should be displayed in the device list
// Otherwise return FALSE
BOOL ShouldDeviceBeListed(WORD vid, WORD pid);

/////////////////////////////////////////////////////////////////////////////
// Static Functions
/////////////////////////////////////////////////////////////////////////////

// Return TRUE if the specified VID/PID should be displayed in the device list
// Otherwise return FALSE
BOOL ShouldDeviceBeListed(WORD vid, WORD pid)
{
	BOOL listed = TRUE;

	// Search through all unlisted VID/PID pairs
	for (int i = 0; i < sizeof(UnlistedDevices)/sizeof(UnlistedDevices[0]); i++)
	{
		// Found a match
		if (vid == UnlistedDevices[i].vid &&
			pid == UnlistedDevices[i].pid)
		{
			listed = FALSE;
			break;
		}
	}

	return listed;
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About
/////////////////////////////////////////////////////////////////////////////

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()

BOOL CAboutDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	CString libStr;

	BYTE major;
	BYTE minor;
	BOOL release;

	if (HidUart_GetLibraryVersion(&major, &minor, &release) == HID_UART_SUCCESS)
	{
		libStr.Format(_T("%u.%u (%s)"), major, minor, (release) ? _T("Release") : _T("Debug"));
		SetDlgItemText(IDC_STATIC_UART_LIBRARY_VERSION, libStr);
	}

	if (HidUart_GetHidLibraryVersion(&major, &minor, &release) == HID_UART_SUCCESS)
	{
		libStr.Format(_T("%u.%u (%s)"), major, minor, (release) ? _T("Release") : _T("Debug"));
		SetDlgItemText(IDC_STATIC_HID_LIBRARY_VERSION, libStr);
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

/////////////////////////////////////////////////////////////////////////////
// CSetIDsDlg dialog
/////////////////////////////////////////////////////////////////////////////

CSetIDsDlg::CSetIDsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSetIDsDlg::IDD, pParent)
	, m_partNumberString(_T(""))
	, m_version(0)
	, m_vid(0)
	, m_pid(0)
	, m_power(0)
	, m_powerMode(0)
	, m_releaseVersionMsb(0)
	, m_releaseVersionLsb(0)
	, m_gpio0(0)
	, m_gpio1(0)
	, m_gpio2(0)
	, m_gpio3(0)
	, m_gpio4(0)
	, m_gpio5(0)
	, m_gpio6(0)
	, m_gpio7(0)
	, m_gpio8(0)
	, m_gpio9(0)
	, m_gpio10(0)
	, m_gpio11(0)
	, m_gpio12(0)
	, m_suspendMode(0)
	, m_suspendValue(0)
	, m_rs485(0)
	, m_clkDiv(0)
	, m_manufacturer(_T(""))
	, m_product(_T(""))
	, m_serial(_T(""))
{
	m_hBigIcon		= AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_hSmallIcon	= (HICON)LoadImage(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME), IMAGE_ICON, 16, 16, 0);
	m_hidUart		= NULL;
}

void CSetIDsDlg::CustomDataExchange(CDataExchange* pDX)
{
	// Power is a 1-byte decimal value in the
	// range [0, HID_UART_BUS_POWER_MAX]
	DDX_TextPlus(pDX, IDC_EDIT_POWER, m_power);
	DDV_MinMaxUInt(pDX, m_power, 0, HID_UART_BUS_POWER_MAX);

	// Release Version MSB is a 1-byte decimal value
	DDX_TextPlus(pDX, IDC_EDIT_RELEASE_VERSION_MSB, m_releaseVersionMsb);

	// Release Version LSB is a 1-byte decimal value
	DDX_TextPlus(pDX, IDC_EDIT_RELEASE_VERSION_LSB, m_releaseVersionLsb);

	// Clock Divider is a 1-byte decimal value
	DDX_TextPlus(pDX, IDC_EDIT_CLK_DIV, m_clkDiv);

	// VID is a 2-byte hex value
	DDX_TextHex(pDX, IDC_EDIT_VID, m_vid);
	DDV_MaxCharsHex(pDX, m_vid);

	// PID is a 2-byte hex value
	DDX_TextHex(pDX, IDC_EDIT_PID, m_pid);
	DDV_MaxCharsHex(pDX, m_pid);

	// Suspend Mode is a 2-byte hex value
	DDX_TextHex(pDX, IDC_EDIT_SUSPEND_MODE, m_suspendMode);
	DDV_MaxCharsHex(pDX, m_suspendMode);

	// Suspend Value is a 2-byte hex value
	DDX_TextHex(pDX, IDC_EDIT_SUSPEND_VALUE, m_suspendValue);
	DDV_MaxCharsHex(pDX, m_suspendValue);

	if (!pDX->m_bSaveAndValidate)
	{
		// Update power edit box in mA
		OnEnChangeEditPower();

		// Update clock output frequency in Hz
		OnEnChangeEditClkDiv();
	}
}

void CSetIDsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	DDX_Control(pDX, IDC_COMBO_DEV_LIST, m_comboDeviceList);
	DDX_Text(pDX, IDC_EDIT_PART_NUMBER, m_partNumberString);
	DDX_Text(pDX, IDC_EDIT_VERSION, m_version);
	DDX_Radio(pDX, IDC_RADIO_POWER_MODE_0, m_powerMode);
	DDX_CBIndex(pDX, IDC_COMBO_GPIO_0, m_gpio0);
	DDV_MinMaxInt(pDX, m_gpio0, 0, 3);
	DDX_CBIndex(pDX, IDC_COMBO_GPIO_1, m_gpio1);
	DDV_MinMaxInt(pDX, m_gpio1, 0, 3);
	DDX_CBIndex(pDX, IDC_COMBO_GPIO_2, m_gpio2);
	DDV_MinMaxInt(pDX, m_gpio2, 0, 3);
	DDX_CBIndex(pDX, IDC_COMBO_GPIO_3, m_gpio3);
	DDV_MinMaxInt(pDX, m_gpio3, 0, 3);
	DDX_CBIndex(pDX, IDC_COMBO_GPIO_4, m_gpio4);
	DDV_MinMaxInt(pDX, m_gpio4, 0, 3);
	DDX_CBIndex(pDX, IDC_COMBO_GPIO_5, m_gpio5);
	DDV_MinMaxInt(pDX, m_gpio5, 0, 3);
	DDX_CBIndex(pDX, IDC_COMBO_GPIO_6, m_gpio6);
	DDV_MinMaxInt(pDX, m_gpio6, 0, 2);
	DDX_CBIndex(pDX, IDC_COMBO_GPIO_7, m_gpio7);
	DDV_MinMaxInt(pDX, m_gpio7, 0, 2);
	DDX_CBIndex(pDX, IDC_COMBO_GPIO_8, m_gpio8);
	DDV_MinMaxInt(pDX, m_gpio8, 0, 2);
	DDX_CBIndex(pDX, IDC_COMBO_GPIO_9, m_gpio9);
	DDV_MinMaxInt(pDX, m_gpio9, 0, 2);
	DDX_CBIndex(pDX, IDC_COMBO_GPIO_10, m_gpio10);
	DDV_MinMaxInt(pDX, m_gpio10, 0, 1);
	DDX_CBIndex(pDX, IDC_COMBO_GPIO_11, m_gpio11);
	DDV_MinMaxInt(pDX, m_gpio11, 0, 1);
	DDX_CBIndex(pDX, IDC_COMBO_GPIO_12, m_gpio12);
	DDV_MinMaxInt(pDX, m_gpio12, 0, 1);
	DDX_Radio(pDX, IDC_RADIO_RS485_0, m_rs485);
	DDX_Text(pDX, IDC_EDIT_MANUFACTURER, m_manufacturer);
	DDX_Text(pDX, IDC_EDIT_PRODUCT, m_product);
	DDX_Text(pDX, IDC_EDIT_SERIAL, m_serial);

	// Call custom DDX and DDV functions in the CustomDDX module
	CustomDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CSetIDsDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_DEVICECHANGE()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDOK, &CSetIDsDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CSetIDsDlg::OnBnClickedCancel)
	ON_WM_CLOSE()
	ON_COMMAND(ID_HELP_ABOUT, &CSetIDsDlg::OnHelpAbout)
	ON_COMMAND(ID_FILE_OPEN, &CSetIDsDlg::OnFileOpen)
	ON_COMMAND(ID_FILE_SAVE, &CSetIDsDlg::OnFileSave)
	ON_COMMAND(ID_FILE_EXIT, &CSetIDsDlg::OnFileExit)
	ON_CBN_SELCHANGE(IDC_COMBO_DEV_LIST, &CSetIDsDlg::OnCbnSelchangeComboDevList)
	ON_CBN_DROPDOWN(IDC_COMBO_DEV_LIST, &CSetIDsDlg::OnCbnDropdownComboDevList)
	ON_CBN_CLOSEUP(IDC_COMBO_DEV_LIST, &CSetIDsDlg::OnCbnCloseupComboDevList)
	ON_BN_CLICKED(IDC_BUTTON_PROGRAM, &CSetIDsDlg::OnBnClickedButtonProgram)
	ON_BN_CLICKED(IDC_CHECK_VID, &CSetIDsDlg::OnBnClickedCheckBox)
	ON_BN_CLICKED(IDC_CHECK_PID, &CSetIDsDlg::OnBnClickedCheckBox)
	ON_BN_CLICKED(IDC_CHECK_POWER, &CSetIDsDlg::OnBnClickedCheckBox)
	ON_BN_CLICKED(IDC_CHECK_POWER_MODE, &CSetIDsDlg::OnBnClickedCheckBox)
	ON_BN_CLICKED(IDC_CHECK_RELEASE_VERSION, &CSetIDsDlg::OnBnClickedCheckBox)
	ON_BN_CLICKED(IDC_CHECK_FLUSH_BUFFERS, &CSetIDsDlg::OnBnClickedCheckBox)
	ON_BN_CLICKED(IDC_CHECK_PIN_CONFIGURATION, &CSetIDsDlg::OnBnClickedCheckBox)
	ON_BN_CLICKED(IDC_CHECK_MANUFACTURER, &CSetIDsDlg::OnBnClickedCheckBox)
	ON_BN_CLICKED(IDC_CHECK_PRODUCT, &CSetIDsDlg::OnBnClickedCheckBox)
	ON_BN_CLICKED(IDC_CHECK_SERIAL, &CSetIDsDlg::OnBnClickedCheckBox)
	ON_COMMAND(ID_FILE_SAVEAS, &CSetIDsDlg::OnFileSaveas)
	ON_BN_CLICKED(IDC_BUTTON_SUSPEND, &CSetIDsDlg::OnBnClickedButtonSuspend)
	ON_EN_CHANGE(IDC_EDIT_POWER, &CSetIDsDlg::OnEnChangeEditPower)
	ON_EN_CHANGE(IDC_EDIT_CLK_DIV, &CSetIDsDlg::OnEnChangeEditClkDiv)
	ON_BN_CLICKED(IDC_BUTTON_GET_CUSTOMIZATION, &CSetIDsDlg::OnBnClickedButtonGetCustomization)
	ON_BN_CLICKED(IDC_BUTTON_RESET, &CSetIDsDlg::OnBnClickedButtonReset)
	ON_CBN_SELCHANGE(IDC_COMBO_GPIO_0, &CSetIDsDlg::OnCbnSelchangeComboGpio0)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSetIDsDlg - Message Handlers
/////////////////////////////////////////////////////////////////////////////

BOOL CSetIDsDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hBigIcon, TRUE);			// Set big icon
	SetIcon(m_hSmallIcon, FALSE);		// Set small icon

	InitializeDialog();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSetIDsDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSetIDsDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hBigIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSetIDsDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hBigIcon);
}

// Handle device change messages (ie a device is added or removed)
// - If an HID device is connected, then add the device to the device list
// - If the device we were connected to was removed, then disconnect from the device
BOOL CSetIDsDlg::OnDeviceChange(UINT nEventType, DWORD_PTR dwData)
{
	// Device has been removed
	if (nEventType == DBT_DEVICEREMOVECOMPLETE ||
		nEventType == DBT_DEVICEARRIVAL)
	{
		if (dwData)
		{
			PDEV_BROADCAST_HDR pHdr = (PDEV_BROADCAST_HDR)dwData;

			if (pHdr->dbch_devicetype == DBT_DEVTYP_DEVICEINTERFACE)
			{
				PDEV_BROADCAST_DEVICEINTERFACE pDevInf = (PDEV_BROADCAST_DEVICEINTERFACE)pHdr;

				// I.E. "\\?\hid#vid_10c4&pid_81ba..."
				CString deviceStr = pDevInf->dbcc_name;

				if (nEventType == DBT_DEVICEREMOVECOMPLETE)
				{
					HID_UART_DEVICE_STR uartDeviceString;

					if (HidUart_GetOpenedString(m_hidUart, uartDeviceString, HID_UART_GET_PATH_STR) == HID_UART_SUCCESS)
					{
						// Our device was removed
						if (deviceStr.CompareNoCase(CString(uartDeviceString)) == 0)
						{
							// Close the device
							DisconnectFromSelected();
						}
					}
				}

				UpdateDeviceList();
			}
		}
	}

	return TRUE;
}

void CSetIDsDlg::OnBnClickedOk()
{
	// Prevent pressing enter from closing the dialog
}

void CSetIDsDlg::OnBnClickedCancel()
{
	// Prevent pressing escape from closing the dialog
}

void CSetIDsDlg::OnClose()
{
	// Override using OnCancel() so that
	// closing the dialog will work
	//
	// Don't use OnOK() because it forces control data
	// to be valid before you can close the dialog
	CDialog::OnCancel();
}

void CSetIDsDlg::OnFileOpen()
{
	if (UpdateData(TRUE))
	{
		CFileDialog openDlg(TRUE, 0, 0, OFN_HIDEREADONLY | OFN_ENABLESIZING, _T("CP2110 Set IDs Files (*.txt)|*.txt|All Files (*.*)|*.*||"));

		if (openDlg.DoModal() == IDOK)
		{
			CString path = openDlg.GetPathName();

			if (Load(path))
			{
				m_filename = path;
				UpdateCaption(m_filename);
			}
			else
			{
				CString msg;
				msg.Format(_T("Failed to load:\r\n%s"), path);
				MessageBox(msg, _T("Load Error"));
			}
		}
	}
}

void CSetIDsDlg::OnFileSave()
{
	if (UpdateData(TRUE))
	{
		if (m_filename.IsEmpty())
		{
			OnFileSaveas();
		}
		else
		{
			if (!Save(m_filename))
			{
				CString msg;
				msg.Format(_T("Failed to save:\r\n%s"), m_filename);
				MessageBox(msg, _T("Save Error"));
			}
		}
	}
}

void CSetIDsDlg::OnFileSaveas()
{
	if (UpdateData(TRUE))
	{
		CString defFname = _T("Custom.txt");

		if (!m_filename.IsEmpty())
		{
			defFname = m_filename;
		}

		CFileDialog saveDlg(FALSE, _T("txt"), defFname, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_ENABLESIZING, _T("CP2110 Set IDs Files (*.txt)|*.txt|All Files (*.*)|*.*||"));

		if (saveDlg.DoModal() == IDOK)
		{
			CString path = saveDlg.GetPathName();

			if (Save(path))
			{
				m_filename = path;
				UpdateCaption(m_filename);
			}
			else
			{
				CString msg;
				msg.Format(_T("Failed to save:\r\n%s"), path);
				MessageBox(msg, _T("Save Error"));
			}
		}
	}
}

void CSetIDsDlg::OnFileExit()
{
	OnClose();
}

void CSetIDsDlg::OnHelpAbout()
{
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
}

// Convert the power decimal value to milliamps
void CSetIDsDlg::OnEnChangeEditPower()
{
	CString power;
	GetDlgItemText(IDC_EDIT_POWER, power);

	UINT powerValue = _tcstoul(power, NULL, 10);

	CString power_mA;

	if (powerValue >= 0 && powerValue <= 250)
	{
		power_mA.Format(_T("%u"), powerValue * 2);
	}
	else
	{
		power_mA = _T("Invalid");
	}

	SetDlgItemText(IDC_EDIT_POWER_MA, power_mA);
}

// Convert the CLK Output Speed using
// the CLK Output Divider
void CSetIDsDlg::OnEnChangeEditClkDiv()
{
	CString clkDiv;
	GetDlgItemText(IDC_EDIT_CLK_DIV, clkDiv);

	UINT clkDivValue = _tcstoul(clkDiv, NULL, 10);

	CString clk_Hz;

	if (clkDivValue == 0)
	{
		clk_Hz = _T("24000000");
	}
	else if (clkDivValue >= 0 && clkDivValue <= 255)
	{
		clk_Hz.Format(_T("%u"), 24000000/(clkDivValue * 2));
	}
	else
	{
		clk_Hz = _T("Invalid");
	}

	SetDlgItemText(IDC_EDIT_CLK_OUTPUT, clk_Hz);
}

void CSetIDsDlg::OnBnClickedButtonGetCustomization()
{
	GetCustomization();
}

void CSetIDsDlg::OnBnClickedButtonReset()
{
	// Send a command to the device to reset and
	// re-enumerate
	Reset();
}

void CSetIDsDlg::OnCbnSelchangeComboDevList()
{
	GetCustomization();
}

void CSetIDsDlg::OnCbnDropdownComboDevList()
{
	UpdateDeviceList();
}

void CSetIDsDlg::OnCbnCloseupComboDevList()
{
	BOOL		found	= FALSE;
	int			sel;
	CString		selText;

	// Check if the selected device has been removed or is in
	// use by another application

	sel = m_comboDeviceList.GetCurSel();

	if (sel != CB_ERR)
	{
		m_comboDeviceList.GetLBText(sel, selText);

		HID_UART_DEVICE_STR		deviceString;
		DWORD					numDevices;

		// Search all HID devices for the selected device based on device path string
		if (HidUart_GetNumDevices(&numDevices, VID, PID) == HID_UART_SUCCESS)
		{
			for (DWORD i = 0; i < numDevices; i++)
			{
				if (HidUart_GetString(i, VID, PID, deviceString, HID_UART_GET_PATH_STR) == HID_UART_SUCCESS)
				{
					if (selText.CompareNoCase(CString(deviceString)) == 0)
					{
						found = TRUE;
						break;
					}
				}
			}
		}
	}

	// Update the device list if the selected device is not availabled
	if (!found)
	{
		UpdateDeviceList();
	}
}

void CSetIDsDlg::OnBnClickedButtonProgram()
{
	SetCustomization();
}

void CSetIDsDlg::OnBnClickedCheckBox()
{
	UpdateCheckState();
}

void CSetIDsDlg::OnCbnSelchangeComboGpio0()
{
	UpdateCheckState();
}

void CSetIDsDlg::OnBnClickedButtonSuspend()
{
	if (UpdateData(TRUE))
	{
		CSuspendDlg dlg;

		dlg.m_suspendMode	= m_suspendMode;
		dlg.m_suspendValue	= m_suspendValue;

		// Prompt user for suspend mode and value
		if (dlg.DoModal() == IDOK)
		{
			// Update suspend fields
			m_suspendMode	= dlg.m_suspendMode;
			m_suspendValue	= dlg.m_suspendValue;
			UpdateData(FALSE);
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
// CSetIDsDlg - Protected Methods
/////////////////////////////////////////////////////////////////////////////

void CSetIDsDlg::InitializeDialog()
{
	InitCaption();
	UpdateDeviceList();
	RegisterDeviceChange();
}

void CSetIDsDlg::InitCaption()
{
	CString caption;
	caption.LoadString(IDS_CAPTION);
	SetWindowText(caption);
}

// Register for device change notification for USB HID devices
// OnDeviceChange() will handle device arrival and removal
void CSetIDsDlg::RegisterDeviceChange()
{
	DEV_BROADCAST_DEVICEINTERFACE devIF = {0};

	devIF.dbcc_size			= sizeof(devIF);    
	devIF.dbcc_devicetype	= DBT_DEVTYP_DEVICEINTERFACE;    
	
	HidUart_GetHidGuid(&devIF.dbcc_classguid);
	
	m_hNotifyDevNode = RegisterDeviceNotification(GetSafeHwnd(), &devIF, DEVICE_NOTIFY_WINDOW_HANDLE);
}

// Unregister for device change notification for USB HID devices
void CSetIDsDlg::UnregisterDeviceChange()
{
	if (m_hNotifyDevNode)
	{
		UnregisterDeviceNotification(m_hNotifyDevNode);
		m_hNotifyDevNode = NULL;
	}
}

// Append save filename to the window caption
void CSetIDsDlg::UpdateCaption(CString saveFilename)
{
	TCHAR drive[_MAX_DRIVE];
	TCHAR dir[_MAX_DIR];
	TCHAR fname[_MAX_FNAME];
	TCHAR ext[_MAX_EXT];

	_tsplitpath_s(saveFilename, drive, _MAX_DRIVE, dir, _MAX_DIR, fname, _MAX_FNAME, ext, _MAX_EXT);

	CString caption;
	caption.LoadString(IDS_CAPTION);
	caption += _T(" - ");
	caption += fname;
	caption += ext;
	SetWindowText(caption);
}

// Populate the device list combo box with connected device path strings
// - Save previous device path string selection
// - Fill the device list with connected device path strings
// - Restore previous device selection
void CSetIDsDlg::UpdateDeviceList()
{
	// Only update the combo list when the drop down list is closed
	if (!m_comboDeviceList.GetDroppedState())
	{
		int			sel;
		CString		selText;

		// Save previous device path string selection
		sel = m_comboDeviceList.GetCurSel();

		if (sel != CB_ERR)
		{
			m_comboDeviceList.GetLBText(sel, selText);
		}

		DWORD					numDevices;
		HID_UART_DEVICE_STR		uartDeviceString;

		// Remove all devices from the device list
		m_comboDeviceList.ResetContent();

		// Fill the device path list for CP2110 devices
		// If VID/PID are both 0, then all HID devices will be listed
		if (HidUart_GetNumDevices(&numDevices, VID, PID) == HID_UART_SUCCESS)
		{
			for (DWORD i = 0; i < numDevices; i++)
			{
				WORD vid;
				WORD pid;
				WORD releaseNumber;

				// Get the device VID, PID, and release number
				if (HidUart_GetAttributes(i, VID, PID, &vid, &pid, &releaseNumber) == HID_UART_SUCCESS)
				{
					// Check to see if the current device should be listed
					if (ShouldDeviceBeListed(vid, pid))
					{
						// Get the device path
						if (HidUart_GetString(i, VID, PID, uartDeviceString, HID_UART_GET_PATH_STR) == HID_UART_SUCCESS)
						{
							// Add the device path to the device list
							m_comboDeviceList.AddString(CString(uartDeviceString));
						}
					}
				}
			}
		}

		// Restore previous device selection
		sel = m_comboDeviceList.FindStringExact(-1, selText);

		// If set selection fails
		if (m_comboDeviceList.SetCurSel(sel) == CB_ERR)
		{
			// Then select the first item
			m_comboDeviceList.SetCurSel(0);
		}

		// Update customization when a device is selected
		GetCustomization();
	}
}

// Enable/disable customization fields
// based on the lock value
void CSetIDsDlg::UpdateLockState()
{
	WORD lock = 0x0000;

	HidUart_GetLock(m_hidUart, &lock);

	// Uncheck the program field checkbox if the field has already been programmed/locked
	if (!(lock & HID_UART_LOCK_VID))				CheckDlgButton(IDC_CHECK_VID,				FALSE);
	if (!(lock & HID_UART_LOCK_PID))				CheckDlgButton(IDC_CHECK_PID,				FALSE);
	if (!(lock & HID_UART_LOCK_POWER))				CheckDlgButton(IDC_CHECK_POWER,				FALSE);
	if (!(lock & HID_UART_LOCK_POWER_MODE))			CheckDlgButton(IDC_CHECK_POWER_MODE,		FALSE);
	if (!(lock & HID_UART_LOCK_RELEASE_VERSION))	CheckDlgButton(IDC_CHECK_RELEASE_VERSION,	FALSE);
	if (!(lock & HID_UART_LOCK_FLUSH_BUFFERS))		CheckDlgButton(IDC_CHECK_FLUSH_BUFFERS,		FALSE);
	if (!(lock & HID_UART_LOCK_PIN_CONFIG))			CheckDlgButton(IDC_CHECK_PIN_CONFIGURATION, FALSE);
	if (!(lock & HID_UART_LOCK_MFG_STR_1))			CheckDlgButton(IDC_CHECK_MANUFACTURER,		FALSE);
	if (!(lock & HID_UART_LOCK_PRODUCT_STR_1))		CheckDlgButton(IDC_CHECK_PRODUCT,			FALSE);
	if (!(lock & HID_UART_LOCK_SERIAL_STR))			CheckDlgButton(IDC_CHECK_SERIAL,			FALSE);

	// Enable the program field checkbox if the field hasn't already been locked
	// and vice versa
	GetDlgItem(IDC_CHECK_VID)->EnableWindow((lock & HID_UART_LOCK_VID) != 0);
	GetDlgItem(IDC_CHECK_PID)->EnableWindow((lock & HID_UART_LOCK_PID) != 0);
	GetDlgItem(IDC_CHECK_POWER)->EnableWindow((lock & HID_UART_LOCK_POWER) != 0);
	GetDlgItem(IDC_CHECK_POWER_MODE)->EnableWindow((lock & HID_UART_LOCK_POWER_MODE) != 0);
	GetDlgItem(IDC_CHECK_RELEASE_VERSION)->EnableWindow((lock & HID_UART_LOCK_RELEASE_VERSION) != 0);
	GetDlgItem(IDC_CHECK_FLUSH_BUFFERS)->EnableWindow((lock & HID_UART_LOCK_FLUSH_BUFFERS) != 0);
	GetDlgItem(IDC_CHECK_PIN_CONFIGURATION)->EnableWindow((lock & HID_UART_LOCK_PIN_CONFIG) != 0);
	GetDlgItem(IDC_CHECK_MANUFACTURER)->EnableWindow((lock & HID_UART_LOCK_MFG_STR_1) != 0);
	GetDlgItem(IDC_CHECK_PRODUCT)->EnableWindow((lock & HID_UART_LOCK_PRODUCT_STR_1) != 0);
	GetDlgItem(IDC_CHECK_SERIAL)->EnableWindow((lock & HID_UART_LOCK_SERIAL_STR) != 0);

	// Uncheck and disable the lock all checkbox if all fields are already locked
	if (lock == 0x0000)
	{
		CheckDlgButton(IDC_CHECK_LOCK_ALL, FALSE);
		GetDlgItem(IDC_CHECK_LOCK_ALL)->EnableWindow(FALSE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_LOCK_ALL)->EnableWindow(TRUE);
	}
}

// Enable all customization fields
void CSetIDsDlg::UpdateLockState_Clear()
{
	GetDlgItem(IDC_CHECK_VID)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHECK_PID)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHECK_POWER)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHECK_POWER_MODE)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHECK_RELEASE_VERSION)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHECK_FLUSH_BUFFERS)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHECK_PIN_CONFIGURATION)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHECK_MANUFACTURER)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHECK_PRODUCT)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHECK_SERIAL)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHECK_LOCK_ALL)->EnableWindow(TRUE);
}

// Enable/disable customization fields if the
// corresponding program checkbox is checked/unchecked
void CSetIDsDlg::UpdateCheckState()
{
	CComboBox* pClkCombo = (CComboBox*)GetDlgItem(IDC_COMBO_GPIO_0);

	GetDlgItem(IDC_EDIT_VID)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_VID));
	GetDlgItem(IDC_EDIT_PID)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_PID));
	GetDlgItem(IDC_EDIT_POWER)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_POWER));
	GetDlgItem(IDC_RADIO_POWER_MODE_0)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_POWER_MODE));
	GetDlgItem(IDC_RADIO_POWER_MODE_1)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_POWER_MODE));
	GetDlgItem(IDC_RADIO_POWER_MODE_2)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_POWER_MODE));
	GetDlgItem(IDC_EDIT_RELEASE_VERSION_MSB)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_RELEASE_VERSION));
	GetDlgItem(IDC_EDIT_RELEASE_VERSION_LSB)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_RELEASE_VERSION));
	GetDlgItem(IDC_CHECK_FLUSH_BUFFERS_1)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_FLUSH_BUFFERS));
	GetDlgItem(IDC_CHECK_FLUSH_BUFFERS_2)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_FLUSH_BUFFERS));
	GetDlgItem(IDC_CHECK_FLUSH_BUFFERS_4)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_FLUSH_BUFFERS));
	GetDlgItem(IDC_CHECK_FLUSH_BUFFERS_8)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_FLUSH_BUFFERS));
	GetDlgItem(IDC_COMBO_GPIO_0)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_PIN_CONFIGURATION));
	GetDlgItem(IDC_COMBO_GPIO_1)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_PIN_CONFIGURATION));
	GetDlgItem(IDC_COMBO_GPIO_2)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_PIN_CONFIGURATION));
	GetDlgItem(IDC_COMBO_GPIO_3)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_PIN_CONFIGURATION));
	GetDlgItem(IDC_COMBO_GPIO_4)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_PIN_CONFIGURATION));
	GetDlgItem(IDC_COMBO_GPIO_5)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_PIN_CONFIGURATION));
	GetDlgItem(IDC_COMBO_GPIO_6)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_PIN_CONFIGURATION));
	GetDlgItem(IDC_COMBO_GPIO_7)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_PIN_CONFIGURATION));
	GetDlgItem(IDC_COMBO_GPIO_8)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_PIN_CONFIGURATION));
	GetDlgItem(IDC_COMBO_GPIO_9)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_PIN_CONFIGURATION));
	GetDlgItem(IDC_COMBO_GPIO_10)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_PIN_CONFIGURATION));
	GetDlgItem(IDC_COMBO_GPIO_11)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_PIN_CONFIGURATION));
	GetDlgItem(IDC_COMBO_GPIO_12)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_PIN_CONFIGURATION));
	GetDlgItem(IDC_CHECK_USE_SUSPEND_VALUES)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_PIN_CONFIGURATION));
	GetDlgItem(IDC_BUTTON_SUSPEND)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_PIN_CONFIGURATION));
	GetDlgItem(IDC_RADIO_RS485_0)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_PIN_CONFIGURATION));
	GetDlgItem(IDC_RADIO_RS485_1)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_PIN_CONFIGURATION));
	GetDlgItem(IDC_EDIT_CLK_DIV)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_PIN_CONFIGURATION) && pClkCombo->GetCurSel() == HID_UART_GPIO_MODE_FUNCTION);
	GetDlgItem(IDC_EDIT_MANUFACTURER)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_MANUFACTURER));
	GetDlgItem(IDC_EDIT_PRODUCT)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_PRODUCT));
	GetDlgItem(IDC_EDIT_SERIAL)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_SERIAL));
}

// Connect to an HID device with a device path that matches
// the selected device path in the device combobox
BOOL CSetIDsDlg::ConnectToSelected()
{
	DWORD	numDevices	= 0;
	BOOL	found		= FALSE;
	BOOL	connected	= FALSE;
	DWORD	deviceNum	= 0;

	CString				selectedPath;
	HID_UART_DEVICE_STR deviceString;

	// Get selected device path
	m_comboDeviceList.GetWindowText(selectedPath);

	// Make sure that a device is selected
	if (!selectedPath.IsEmpty())
	{
		// Search through all HID devices for a matching device path
		if (HidUart_GetNumDevices(&numDevices, NULL, NULL) == HID_UART_SUCCESS)
		{
			for (DWORD i = 0; i < numDevices; i++)
			{
				// Get the device path
				if (HidUart_GetString(i, NULL, NULL, deviceString, HID_UART_GET_PATH_STR) == HID_UART_SUCCESS)
				{
					// Check if the path matches the selected device path
					if (selectedPath == deviceString)
					{
						deviceNum	= i;
						found		= TRUE;
						break;
					}
				}
			}
		}

		// Found a device with a matching path
		if (found)
		{
			// Connect to the matching device
			if (HidUart_Open(&m_hidUart, deviceNum, NULL, NULL) == HID_UART_SUCCESS)
			{
				connected = TRUE;
			}
		}
	}

	return connected;
}

// Disconnect from the currently connected device
BOOL CSetIDsDlg::DisconnectFromSelected()
{
	BOOL disconnected = FALSE;

	HID_UART_STATUS status = HidUart_Close(m_hidUart);

	m_hidUart = NULL;

	return disconnected;
}

// Reset the device
void CSetIDsDlg::Reset()
{
	CWaitCursor wait;

	if (ConnectToSelected())
	{
		// Send a command to the device to reset and
		// re-enumerate
		HID_UART_STATUS status = HidUart_Reset(m_hidUart);

		DisconnectFromSelected();

		// Refresh the dialog with the newly programmed values
		GetCustomization();
	}
}

// Connect to selected device and retrieve
// current device customization fields
void CSetIDsDlg::GetCustomization()
{
	CWaitCursor wait;

	UpdateData(TRUE);

	if (ConnectToSelected())
	{
		GetCustomization_Uart();

		UpdateData(FALSE);

		// Enable/disable customization fields
		// based on the lock value
		UpdateLockState();

		// Enable/disable customization fields if the
		// corresponding program checkbox is checked/unchecked
		UpdateCheckState();

		DisconnectFromSelected();
	}
	else
	{
		// Clear device customization fields
		GetCustomization_Clear();
		
		UpdateData(FALSE);

		// Enable all customization fields
		UpdateLockState_Clear();

		// Enable/disable customization fields if the
		// corresponding program checkbox is checked/unchecked
		UpdateCheckState();
	}
}

// Retrieve current device customization fields
void CSetIDsDlg::GetCustomization_Uart()
{
	BYTE partNumber;
	BYTE version;
	
	WORD vid;
	WORD pid;
	BYTE power;
	BYTE powerMode;
	WORD releaseVersion;
	BYTE flushBuffers;
	
	BYTE pinConfig[13];
	BOOL useSuspendValues;
	WORD suspendMode;
	WORD suspendValue;
	BYTE rs485Level;
	BYTE clkDiv;

	HID_UART_MFG_STR		manufacturingString;
	HID_UART_PRODUCT_STR	productString;
	HID_UART_SERIAL_STR		serialString;
	BYTE					strlen;

	// Update part number and version
	if (HidUart_GetPartNumber(m_hidUart, &partNumber, &version) == HID_UART_SUCCESS)
	{
		switch (partNumber)
		{
		case HID_UART_PART_CP2110:	m_partNumberString = _T("CP2110");	break;
		}

		m_version = version;
	}

	// Update Vendor ID, Product ID, power, power mode, release version, and flush buffers settings
	if (HidUart_GetUsbConfig(m_hidUart, &vid, &pid, &power, &powerMode, &releaseVersion, &flushBuffers) == HID_UART_SUCCESS)
	{
		m_vid					= vid;
		m_pid					= pid;
		m_power					= power;
		m_powerMode				= powerMode;
		m_releaseVersionMsb		= (BYTE)(releaseVersion >> 8);
		m_releaseVersionLsb		= (BYTE)(releaseVersion);
		
		CheckDlgButton(IDC_CHECK_FLUSH_BUFFERS_1, (flushBuffers & HID_UART_FLUSH_TX_OPEN)  != 0);
		CheckDlgButton(IDC_CHECK_FLUSH_BUFFERS_2, (flushBuffers & HID_UART_FLUSH_TX_CLOSE) != 0);
		CheckDlgButton(IDC_CHECK_FLUSH_BUFFERS_4, (flushBuffers & HID_UART_FLUSH_RX_OPEN)  != 0);
		CheckDlgButton(IDC_CHECK_FLUSH_BUFFERS_8, (flushBuffers & HID_UART_FLUSH_RX_CLOSE) != 0);
	}

	// Update pin config, suspend value, suspend mode, and RS485 logic level
	if (HidUart_GetPinConfig(m_hidUart, pinConfig, &useSuspendValues, &suspendValue, &suspendMode, &rs485Level, &clkDiv) == HID_UART_SUCCESS)
	{
		m_gpio0 		= pinConfig[0];
		m_gpio1 		= pinConfig[1];
		m_gpio2 		= pinConfig[2];
		m_gpio3 		= pinConfig[3];
		m_gpio4 		= pinConfig[4];
		m_gpio5 		= pinConfig[5];
		m_gpio6 		= pinConfig[6];
		m_gpio7 		= pinConfig[7];
		m_gpio8 		= pinConfig[8];
		m_gpio9			= pinConfig[9];

		// Offset combobox indices to be zero-based
		m_gpio10		= pinConfig[10] - HID_UART_GPIO_MODE_OUTPUT_OD;	// TX:			HID_UART_GPIO_MODE_OUTPUT_OD or HID_UART_GPIO_MODE_OUTPUT_PP
		m_gpio11		= pinConfig[11] - HID_UART_GPIO_MODE_OUTPUT_OD;	// Suspend:		HID_UART_GPIO_MODE_OUTPUT_OD or HID_UART_GPIO_MODE_OUTPUT_PP
		m_gpio12		= pinConfig[12] - HID_UART_GPIO_MODE_OUTPUT_OD;	// /Suspend:	HID_UART_GPIO_MODE_OUTPUT_OD or HID_UART_GPIO_MODE_OUTPUT_PP

		CheckDlgButton(IDC_CHECK_USE_SUSPEND_VALUES, useSuspendValues);

		m_suspendMode	= suspendMode;
		m_suspendValue	= suspendValue;

		m_rs485			= rs485Level;

		m_clkDiv		= clkDiv;
	}

	// Update manufacturer string
	if (HidUart_GetManufacturingString(m_hidUart, manufacturingString, &strlen) == HID_UART_SUCCESS)
	{
		m_manufacturer = CString(manufacturingString, strlen);
	}

	// Update product string
	if (HidUart_GetProductString(m_hidUart, productString, &strlen) == HID_UART_SUCCESS)
	{
		m_product = CString(productString, strlen);
	}

	// Update serial string
	if (HidUart_GetSerialString(m_hidUart, serialString, &strlen) == HID_UART_SUCCESS)
	{
		m_serial = CString(serialString, strlen);
	}
}

// Clear device customization fields
void CSetIDsDlg::GetCustomization_Clear()
{
	// Reset all dialog controls to default values

	m_partNumberString		= _T("");
	m_version				= 0;
	
	m_vid					= 0;
	m_pid					= 0;
	m_power					= 0;
	m_powerMode				= 0;
	m_releaseVersionMsb		= 0;
	m_releaseVersionLsb		= 0;
	CheckDlgButton(IDC_CHECK_FLUSH_BUFFERS_1, FALSE);
	CheckDlgButton(IDC_CHECK_FLUSH_BUFFERS_2, FALSE);
	CheckDlgButton(IDC_CHECK_FLUSH_BUFFERS_4, FALSE);
	CheckDlgButton(IDC_CHECK_FLUSH_BUFFERS_8, FALSE);

	m_gpio0					= 0;
	m_gpio1					= 0;
	m_gpio2					= 0;
	m_gpio3					= 0;
	m_gpio4					= 0;
	m_gpio5					= 0;
	m_gpio6					= 0;
	m_gpio7					= 0;
	m_gpio8					= 0;
	m_gpio9					= 0;
	m_gpio10				= 0;
	m_gpio11				= 0;
	m_gpio12				= 0;

	CheckDlgButton(IDC_CHECK_USE_SUSPEND_VALUES, FALSE);

	m_suspendMode			= 0;
	m_suspendValue			= 0;
	m_rs485					= 0;
	m_clkDiv				= 0;

	m_manufacturer			= _T("");
	m_product				= _T("");
	m_serial				= _T("");
}

// Connect to selected device and program
// new device customization fields
void CSetIDsDlg::SetCustomization()
{
	CWaitCursor wait;

	if (UpdateData(TRUE))
	{
		CString selectedPath;

		// Get selected device path
		m_comboDeviceList.GetWindowText(selectedPath);
		
		if (!selectedPath.IsEmpty())
		{
			// Connect to the selected device
			if (ConnectToSelected())
			{
				BOOL valid = ValidateFields();

				if (valid)
				{
					SetCustomization_Uart();
				}

				DisconnectFromSelected();

				if (valid)
				{
					// Refresh the dialog with the newly programmed values
					GetCustomization();
				}
			}
			else
			{
				CString msg;
				msg.Format(_T("Could not connect to %s"), selectedPath);
				MessageBox(msg, _T("Connection Error"));
			}
		}
	}
}

// Program selected device customization fields
void CSetIDsDlg::SetCustomization_Uart()
{
	SET_STATUS status;

	// Program USB configuration
	if ((status = ProgramUsbConfig()) != SET_SUCCESS)
	{
		MessageBox(_T("Failed to program USB Configuration field(s)"), _T("Programming Error"));
	}
	// Program pin configuration
	else if ((status = ProgramPinConfig()) != SET_SUCCESS)
	{
		MessageBox(_T("Failed to program Pin Configuration field(s)"), _T("Programming Error"));
	}
	// Program Manufacturer String
	else if ((status = ProgramManufacturerString()) != SET_SUCCESS)
	{
		MessageBox(_T("Failed to program manufacturer string field"), _T("Programming Error"));
	}
	// Program Product String
	else if ((status = ProgramProductString()) != SET_SUCCESS)
	{
		MessageBox(_T("Failed to program product string field"), _T("Programming Error"));
	}
	// Program Serial String
	else if ((status = ProgramSerialString()) != SET_SUCCESS)
	{
		MessageBox(_T("Failed to program serial string field"), _T("Programming Error"));
	}
	// Program Lock field
	else if ((status = ProgramLockAll()) != SET_SUCCESS)
	{
		MessageBox(_T("Failed to lock device customization"), _T("Programming Error"));
	}
	// All fields programmed successfully
	else
	{
		MessageBox(_T("All selected fields were programmed succcessfully"), _T("Success"));
	}
}

// Save settings to specified text file in
// plain text
BOOL CSetIDsDlg::Save(CString filename)
{
	BOOL retVal = FALSE;

	if (UpdateData(TRUE))
	{
		CStdioFilePlus file;

		if (file.Open(filename, CFile::modeWrite | CFile::modeCreate))
		{
			BYTE flushBuffers	= 0x00;

			if (IsDlgButtonChecked(IDC_CHECK_FLUSH_BUFFERS_1))	flushBuffers |= HID_UART_FLUSH_TX_OPEN;
			if (IsDlgButtonChecked(IDC_CHECK_FLUSH_BUFFERS_2))	flushBuffers |= HID_UART_FLUSH_TX_CLOSE;
			if (IsDlgButtonChecked(IDC_CHECK_FLUSH_BUFFERS_4))	flushBuffers |= HID_UART_FLUSH_RX_OPEN;
			if (IsDlgButtonChecked(IDC_CHECK_FLUSH_BUFFERS_8))	flushBuffers |= HID_UART_FLUSH_RX_CLOSE;

			// Save USB configuration field state
			file.WriteString(SAVE_STR_VID);				file.WriteDecimal(IsDlgButtonChecked(IDC_CHECK_VID));				file.WriteDecimal(m_vid);
			file.WriteString(SAVE_STR_PID);				file.WriteDecimal(IsDlgButtonChecked(IDC_CHECK_PID));				file.WriteDecimal(m_pid);
			file.WriteString(SAVE_STR_POWER);			file.WriteDecimal(IsDlgButtonChecked(IDC_CHECK_POWER));				file.WriteDecimal(m_power);
			file.WriteString(SAVE_STR_POWER_MODE);		file.WriteDecimal(IsDlgButtonChecked(IDC_CHECK_POWER_MODE));		file.WriteDecimal(m_powerMode);
			file.WriteString(SAVE_STR_RELEASE_VERSION);	file.WriteDecimal(IsDlgButtonChecked(IDC_CHECK_RELEASE_VERSION));	file.WriteDecimal(MAKEWORD(m_releaseVersionLsb, m_releaseVersionMsb));
			file.WriteString(SAVE_STR_FLUSH_BUFFERS);	file.WriteDecimal(IsDlgButtonChecked(IDC_CHECK_FLUSH_BUFFERS));		file.WriteDecimal(flushBuffers);

			// Save pin configuration field state
			file.WriteString(SAVE_STR_PIN_CONFIGURATION);
			file.WriteDecimal(IsDlgButtonChecked(IDC_CHECK_PIN_CONFIGURATION));
			file.WriteDecimal(m_gpio0);
			file.WriteDecimal(m_gpio1);
			file.WriteDecimal(m_gpio2);
			file.WriteDecimal(m_gpio3);
			file.WriteDecimal(m_gpio4);
			file.WriteDecimal(m_gpio5);
			file.WriteDecimal(m_gpio6);
			file.WriteDecimal(m_gpio7);
			file.WriteDecimal(m_gpio8);
			file.WriteDecimal(m_gpio9);
			file.WriteDecimal(m_gpio10);
			file.WriteDecimal(m_gpio11);
			file.WriteDecimal(m_gpio12);
			file.WriteDecimal(IsDlgButtonChecked(IDC_CHECK_USE_SUSPEND_VALUES));
			file.WriteDecimal(m_suspendMode);
			file.WriteDecimal(m_suspendValue);
			file.WriteDecimal(m_rs485);
			file.WriteDecimal(m_clkDiv);

			// Save string descriptors
			file.WriteString(SAVE_STR_MANUFACTURER);	file.WriteDecimal(IsDlgButtonChecked(IDC_CHECK_MANUFACTURER));	file.WriteString(m_manufacturer);
			file.WriteString(SAVE_STR_PRODUCT);			file.WriteDecimal(IsDlgButtonChecked(IDC_CHECK_PRODUCT));		file.WriteString(m_product);
			file.WriteString(SAVE_STR_SERIAL);			file.WriteDecimal(IsDlgButtonChecked(IDC_CHECK_SERIAL));		file.WriteString(m_serial);

			// Save Lock All Checkbox
			file.WriteString(SAVE_STR_LOCK_ALL);		file.WriteDecimal(IsDlgButtonChecked(IDC_CHECK_LOCK_ALL));

			file.Close();

			retVal = TRUE;
		}
	}

	return retVal;
}

// Loads a customization field and the specified number of decimal and string values for the field
// Returns TRUE if the read string matches the field name and if all decimal and string values were read
//
// successOneShot - Used to determine the success of multiple calls to this function
//				    Caller must initially set this value to TRUE
//					Once a single call to this function fails, successOneShot will be
//					set to and remain FALSE until set to true again by the caller
BOOL CSetIDsDlg::LoadFieldValues(BOOL& successOneShot, CStdioFilePlus& file, CString fieldName, UINT* decimalValues, int numDecimalValues, CString* stringValues, int numStringValues)
{
	BOOL retVal = FALSE;

	UINT	decimalValue;
	CString	stringValue;

	// Verify that the next entry in the file
	// matches the field name
	if (file.ReadString(stringValue) && stringValue == fieldName)
	{
		BOOL readValues = TRUE;

		// Read specified number of decimal field values
		for (int i = 0; i < numDecimalValues; i++)
		{
			if (file.ReadDecimal(decimalValue))
			{
				decimalValues[i] = decimalValue;
			}
			else
			{
				readValues = FALSE;
			}
		}

		// Read specified number of string field values
		for (int i = 0; i < numStringValues; i++)
		{
			if (file.ReadString(stringValue))
			{
				stringValues[i] = stringValue;
			}
			else
			{
				readValues = FALSE;
			}
		}

		if (readValues)
		{
			retVal = TRUE;
		}
	}

	if (!retVal)
	{
		successOneShot = FALSE;
	}

	return retVal;
}

// Load settings from specified text file in
// plain text
BOOL CSetIDsDlg::Load(CString filename)
{
	BOOL retVal = FALSE;

	if (UpdateData(TRUE))
	{
		CStdioFilePlus file;

		if (file.Open(filename, CFile::modeRead))
		{
			BOOL		readSuccess	= TRUE;
			UINT		values[19];
			CString		strings[1];

			// Load USB configuration field state
			if (LoadFieldValues(readSuccess, file, SAVE_STR_VID, values, 2, NULL, 0))
			{
				CheckDlgButton(IDC_CHECK_VID, values[0]);
				m_vid = values[1];
			}
			if (LoadFieldValues(readSuccess, file, SAVE_STR_PID, values, 2, NULL, 0))
			{
				CheckDlgButton(IDC_CHECK_PID, values[0]);
				m_pid = values[1];
			}
			if (LoadFieldValues(readSuccess, file, SAVE_STR_POWER, values, 2, NULL, 0))
			{
				CheckDlgButton(IDC_CHECK_POWER, values[0]);
				m_power = values[1];
			}
			if (LoadFieldValues(readSuccess, file, SAVE_STR_POWER_MODE, values, 2, NULL, 0))
			{
				CheckDlgButton(IDC_CHECK_POWER_MODE, values[0]);
				m_powerMode = values[1];
			}
			if (LoadFieldValues(readSuccess, file, SAVE_STR_RELEASE_VERSION, values, 2, NULL, 0))
			{
				CheckDlgButton(IDC_CHECK_RELEASE_VERSION, values[0]);
				m_releaseVersionMsb = (BYTE)(values[1] >> 8);
				m_releaseVersionLsb = (BYTE)(values[1]);
			}
			if (LoadFieldValues(readSuccess, file, SAVE_STR_FLUSH_BUFFERS, values, 2, NULL, 0))
			{
				CheckDlgButton(IDC_CHECK_FLUSH_BUFFERS, values[0]);
				CheckDlgButton(IDC_CHECK_FLUSH_BUFFERS_1, (values[1] & HID_UART_FLUSH_TX_OPEN) != 0);
				CheckDlgButton(IDC_CHECK_FLUSH_BUFFERS_2, (values[1] & HID_UART_FLUSH_TX_CLOSE) != 0);
				CheckDlgButton(IDC_CHECK_FLUSH_BUFFERS_4, (values[1] & HID_UART_FLUSH_RX_OPEN) != 0);
				CheckDlgButton(IDC_CHECK_FLUSH_BUFFERS_8, (values[1] & HID_UART_FLUSH_RX_CLOSE) != 0);
			}

			// Load pin configuration field state
			if (LoadFieldValues(readSuccess, file, SAVE_STR_PIN_CONFIGURATION, values, 19, NULL, 0))
			{
				CheckDlgButton(IDC_CHECK_PIN_CONFIGURATION, values[0]);
				m_gpio0			= values[1];
				m_gpio1			= values[2];
				m_gpio2			= values[3];
				m_gpio3			= values[4];
				m_gpio4			= values[5];
				m_gpio5			= values[6];
				m_gpio6			= values[7];
				m_gpio7			= values[8];
				m_gpio8			= values[9];
				m_gpio9			= values[10];
				m_gpio10		= values[11];
				m_gpio11		= values[12];
				m_gpio12		= values[13];
				CheckDlgButton(IDC_CHECK_USE_SUSPEND_VALUES, values[14]);
				m_suspendMode	= values[15];
				m_suspendValue	= values[16];
				m_rs485			= values[17];
				m_clkDiv		= values[18];
			}

			// Load string descriptors
			if (LoadFieldValues(readSuccess, file, SAVE_STR_MANUFACTURER, values, 1, strings, 1))
			{
				CheckDlgButton(IDC_CHECK_MANUFACTURER, values[0]);
				m_manufacturer = strings[0];
			}
			if (LoadFieldValues(readSuccess, file, SAVE_STR_PRODUCT, values, 1, strings, 1))
			{
				CheckDlgButton(IDC_CHECK_PRODUCT, values[0]);
				m_product = strings[0];
			}
			if (LoadFieldValues(readSuccess, file, SAVE_STR_SERIAL, values, 1, strings, 1))
			{
				CheckDlgButton(IDC_CHECK_SERIAL, values[0]);
				m_serial = strings[0];
			}

			// Load Lock All Checkbox
			if (LoadFieldValues(readSuccess, file, SAVE_STR_LOCK_ALL, values, 1, NULL, 0))
			{
				CheckDlgButton(IDC_CHECK_LOCK_ALL, values[0]);
			}

			if (readSuccess)
			{
				retVal = TRUE;
			}

			file.Close();
			UpdateData(FALSE);

			// If a checkbox is disabled, this means that the field has been locked
			// Uncheck the checkbox
			if (!GetDlgItem(IDC_CHECK_VID)->IsWindowEnabled())					CheckDlgButton(IDC_CHECK_VID, FALSE);
			if (!GetDlgItem(IDC_CHECK_PID)->IsWindowEnabled())					CheckDlgButton(IDC_CHECK_PID, FALSE);
			if (!GetDlgItem(IDC_CHECK_POWER)->IsWindowEnabled())				CheckDlgButton(IDC_CHECK_POWER, FALSE);
			if (!GetDlgItem(IDC_CHECK_POWER_MODE)->IsWindowEnabled())			CheckDlgButton(IDC_CHECK_POWER_MODE, FALSE);
			if (!GetDlgItem(IDC_CHECK_RELEASE_VERSION)->IsWindowEnabled())		CheckDlgButton(IDC_CHECK_RELEASE_VERSION, FALSE);
			if (!GetDlgItem(IDC_CHECK_FLUSH_BUFFERS)->IsWindowEnabled())		CheckDlgButton(IDC_CHECK_FLUSH_BUFFERS, FALSE);
			if (!GetDlgItem(IDC_CHECK_PIN_CONFIGURATION)->IsWindowEnabled())	CheckDlgButton(IDC_CHECK_PIN_CONFIGURATION, FALSE);
			if (!GetDlgItem(IDC_CHECK_MANUFACTURER)->IsWindowEnabled())			CheckDlgButton(IDC_CHECK_MANUFACTURER, FALSE);
			if (!GetDlgItem(IDC_CHECK_PRODUCT)->IsWindowEnabled())				CheckDlgButton(IDC_CHECK_PRODUCT, FALSE);
			if (!GetDlgItem(IDC_CHECK_SERIAL)->IsWindowEnabled())				CheckDlgButton(IDC_CHECK_SERIAL, FALSE);
			if (!GetDlgItem(IDC_CHECK_LOCK_ALL)->IsWindowEnabled())				CheckDlgButton(IDC_CHECK_LOCK_ALL, FALSE);

			// Enable/disable customization fields if the
			// corresponding program checkbox is checked/unchecked
			UpdateCheckState();
		}
	}

	return retVal;
}

/////////////////////////////////////////////////////////////////////////////
// CSetIDsDlg - Programming Methods
/////////////////////////////////////////////////////////////////////////////

// Program and verify the usb configuration customization fields
SET_STATUS CSetIDsDlg::ProgramUsbConfig()
{
	SET_STATUS status = SET_FAIL;

	// Populate customization field values
	BYTE mask				= 0x00;
	WORD vid				= (WORD)m_vid;
	WORD pid				= (WORD)m_pid;
	BYTE power				= m_power;
	BYTE powerMode			= (BYTE)m_powerMode;
	WORD releaseVersion		= ((WORD)m_releaseVersionMsb << 8) | m_releaseVersionLsb;
	BYTE flushBuffers		= 0x00;

	// Populate flushBuffers field value
	if (IsDlgButtonChecked(IDC_CHECK_FLUSH_BUFFERS_1))	flushBuffers |= HID_UART_FLUSH_TX_OPEN;
	if (IsDlgButtonChecked(IDC_CHECK_FLUSH_BUFFERS_2))	flushBuffers |= HID_UART_FLUSH_TX_CLOSE;
	if (IsDlgButtonChecked(IDC_CHECK_FLUSH_BUFFERS_4))	flushBuffers |= HID_UART_FLUSH_RX_OPEN;
	if (IsDlgButtonChecked(IDC_CHECK_FLUSH_BUFFERS_8))	flushBuffers |= HID_UART_FLUSH_RX_CLOSE;

	// Set program mask based on which checkboxes are checked
	if (IsDlgButtonChecked(IDC_CHECK_VID))					mask |= HID_UART_SET_VID;
	if (IsDlgButtonChecked(IDC_CHECK_PID))					mask |= HID_UART_SET_PID;
	if (IsDlgButtonChecked(IDC_CHECK_POWER))				mask |= HID_UART_SET_POWER;
	if (IsDlgButtonChecked(IDC_CHECK_POWER_MODE))			mask |= HID_UART_SET_POWER_MODE;
	if (IsDlgButtonChecked(IDC_CHECK_RELEASE_VERSION))		mask |= HID_UART_SET_RELEASE_VERSION;
	if (IsDlgButtonChecked(IDC_CHECK_FLUSH_BUFFERS))		mask |= HID_UART_SET_FLUSH_BUFFERS;

	// Fields were checked to be programmed
	if (mask != 0x00)
	{
		// Set customization field values
		if (HidUart_SetUsbConfig(m_hidUart, vid, pid, power, powerMode, releaseVersion, flushBuffers, mask) == HID_UART_SUCCESS)
		{
			WORD newVid;
			WORD newPid;
			BYTE newPower;
			BYTE newPowerMode;
			WORD newReleaseVersion;
			BYTE newFlushBuffers;

			status = SET_VERIFY_FAIL;

			// Get customization field values
			if (HidUart_GetUsbConfig(m_hidUart, &newVid, &newPid, &newPower, &newPowerMode, &newReleaseVersion, &newFlushBuffers) == HID_UART_SUCCESS)
			{
				// Verify that fields that were checked were programmed
				// successfully
				if (((!(mask & HID_UART_SET_VID)) || (newVid == vid)) &&
					((!(mask & HID_UART_SET_PID)) || (newPid == pid)) &&
					((!(mask & HID_UART_SET_POWER)) || (newPower == power)) &&
					((!(mask & HID_UART_SET_POWER_MODE)) || (newVid == vid)) &&
					((!(mask & HID_UART_SET_RELEASE_VERSION)) || (newVid == vid)) &&
					((!(mask & HID_UART_SET_FLUSH_BUFFERS)) || (newVid == vid)))
				{
					status = SET_SUCCESS;
				}
			}
		}
	}
	// No USB config fields were checked
	else
	{
		status = SET_SUCCESS;
	}

	return status;
}

// Program and verify the pin configuration customization fields
SET_STATUS CSetIDsDlg::ProgramPinConfig()
{
	SET_STATUS status = SET_FAIL;

	// Pin Config is checked
	if (IsDlgButtonChecked(IDC_CHECK_PIN_CONFIGURATION))
	{
		// Populate customization field values
		BYTE pinConfig[13];
		BOOL useSuspendValues	= FALSE;
		WORD suspendMode		= m_suspendMode;
		WORD suspendValue		= m_suspendValue;
		BYTE rs485Level			= (BYTE)m_rs485;
		BYTE clkDiv				= m_clkDiv;

		// Populate pinConfig field value
		pinConfig[0]	= m_gpio0;
		pinConfig[1]	= m_gpio1;
		pinConfig[2]	= m_gpio2;
		pinConfig[3]	= m_gpio3;
		pinConfig[4]	= m_gpio4;
		pinConfig[5]	= m_gpio5;
		pinConfig[6]	= m_gpio6;
		pinConfig[7]	= m_gpio7;
		pinConfig[8]	= m_gpio8;
		pinConfig[9]	= m_gpio9;

		// Combobox indices were offset to be zero-based
		// Undo the offset to get the actual pin config value
		pinConfig[10]	= m_gpio10 + HID_UART_GPIO_MODE_OUTPUT_OD;	// TX:			HID_UART_GPIO_MODE_OUTPUT_OD or HID_UART_GPIO_MODE_OUTPUT_PP
		pinConfig[11]	= m_gpio11 + HID_UART_GPIO_MODE_OUTPUT_OD;	// Suspend:		HID_UART_GPIO_MODE_OUTPUT_OD or HID_UART_GPIO_MODE_OUTPUT_PP
		pinConfig[12]	= m_gpio12 + HID_UART_GPIO_MODE_OUTPUT_OD;	// /Suspend:	HID_UART_GPIO_MODE_OUTPUT_OD or HID_UART_GPIO_MODE_OUTPUT_PP

		useSuspendValues = IsDlgButtonChecked(IDC_CHECK_USE_SUSPEND_VALUES);

		// Set customization field values
		if (HidUart_SetPinConfig(m_hidUart, pinConfig, useSuspendValues, suspendValue, suspendMode, rs485Level, clkDiv) == HID_UART_SUCCESS)
		{
			BYTE newPinConfig[13];
			BOOL newUseSuspendValues;
			WORD newSuspendMode;
			WORD newSuspendValue;
			BYTE newRs485Level;
			BYTE newClkDiv;

			status = SET_VERIFY_FAIL;

			// Get customization field values
			if (HidUart_GetPinConfig(m_hidUart, newPinConfig, &newUseSuspendValues, &newSuspendValue, &newSuspendMode, &newRs485Level, &newClkDiv) == HID_UART_SUCCESS)
			{
				// Bit 15 will be set to indicate that suspend mode and value
				// configuration will be used
				if (useSuspendValues)
				{
					suspendMode |= 0x8000;
				}

				// Verify that fields that were checked were programmed
				// successfully
				if ((memcmp(newPinConfig, pinConfig, sizeof(pinConfig)) == 0) &&
					(newSuspendMode == suspendMode) &&
					(newSuspendValue == suspendValue) &&
					(newRs485Level == rs485Level) &&
					(newClkDiv == clkDiv))
				{
					status = SET_SUCCESS;
				}
			}
		}
	}
	// Pin Config is not checked
	else
	{
		status = SET_SUCCESS;
	}

	return status;
}

// Program and verify the manufacturer string customization field
SET_STATUS CSetIDsDlg::ProgramManufacturerString()
{
	SET_STATUS status = SET_FAIL;

	// Manufacturer string is checked
	if (IsDlgButtonChecked(IDC_CHECK_MANUFACTURER))
	{
		HID_UART_MFG_STR	mfrString;
		BYTE				strlen = 0;

		strlen = m_manufacturer.GetLength();

		// Convert Unicode CString to
		// ASCII character array
		for (int i = 0; i < strlen; i++)
		{
			mfrString[i] = (char)m_manufacturer[i];
		}

		// Set manufacturer string
		if (HidUart_SetManufacturingString(m_hidUart, mfrString, strlen) == HID_UART_SUCCESS)
		{
			HID_UART_MFG_STR	newMfrString;
			BYTE				newStrlen;

			status = SET_VERIFY_FAIL;

			// Get manufacturer string
			if (HidUart_GetManufacturingString(m_hidUart, newMfrString, &newStrlen) == HID_UART_SUCCESS)
			{
				// Verify that the manufacturer string was programmed successfully
				if (newStrlen == strlen &&
					memcmp(newMfrString, mfrString, strlen) == 0)
				{
					status = SET_SUCCESS;
				}
			}
		}
	}
	// Manufacturer string is not checked
	else
	{
		status = SET_SUCCESS;
	}

	return status;
}

// Program and verify the product string customization field
SET_STATUS CSetIDsDlg::ProgramProductString()
{
	SET_STATUS status = SET_FAIL;

	// Product string is checked
	if (IsDlgButtonChecked(IDC_CHECK_PRODUCT))
	{
		HID_UART_PRODUCT_STR	productString;
		BYTE					strlen = 0;

		strlen = m_product.GetLength();

		// Convert Unicode CString to
		// ASCII character array
		for (int i = 0; i < strlen; i++)
		{
			productString[i] = (char)m_product[i];
		}

		// Set product string
		if (HidUart_SetProductString(m_hidUart, productString, strlen) == HID_UART_SUCCESS)
		{
			HID_UART_PRODUCT_STR	newProductString;
			BYTE					newStrlen;

			status = SET_VERIFY_FAIL;

			// Get product string
			if (HidUart_GetProductString(m_hidUart, newProductString, &newStrlen) == HID_UART_SUCCESS)
			{
				// Verify that the product string was programmed successfully
				if (newStrlen == strlen &&
					memcmp(newProductString, productString, strlen) == 0)
				{
					status = SET_SUCCESS;
				}
			}
		}
	}
	// Product string is not checked
	else
	{
		status = SET_SUCCESS;
	}

	return status;
}

// Program and verify the serial string customization field
SET_STATUS CSetIDsDlg::ProgramSerialString()
{
	SET_STATUS status = SET_FAIL;

	// Serial string is checked
	if (IsDlgButtonChecked(IDC_CHECK_SERIAL))
	{
		HID_UART_SERIAL_STR		serialString;
		BYTE					strlen = 0;

		strlen = m_serial.GetLength();

		// Convert Unicode CString to
		// ASCII character array
		for (int i = 0; i < strlen; i++)
		{
			serialString[i] = (char)m_serial[i];
		}

		// Set serial string
		if (HidUart_SetSerialString(m_hidUart, serialString, strlen) == HID_UART_SUCCESS)
		{
			HID_UART_SERIAL_STR		newSerialString;
			BYTE					newStrlen;

			status = SET_VERIFY_FAIL;

			// Get serial string
			if (HidUart_GetSerialString(m_hidUart, newSerialString, &newStrlen) == HID_UART_SUCCESS)
			{
				// Verify that the serial string was programmed successfully
				if (newStrlen == strlen &&
					memcmp(newSerialString, serialString, strlen) == 0)
				{
					status = SET_SUCCESS;
				}
			}
		}
	}
	// Serial string is not checked
	else
	{
		status = SET_SUCCESS;
	}

	return status;
}

// Program and verify the lock byte customization field
SET_STATUS CSetIDsDlg::ProgramLockAll()
{
	SET_STATUS status = SET_FAIL;

	// Lock all is checked
	if (IsDlgButtonChecked(IDC_CHECK_LOCK_ALL))
	{
		WORD lock = 0x0000;

		// Lock all customization fields
		if (HidUart_SetLock(m_hidUart, lock) == HID_UART_SUCCESS)
		{
			WORD newLock;

			status = SET_VERIFY_FAIL;

			// Get lock value
			if (HidUart_GetLock(m_hidUart, &newLock) == HID_UART_SUCCESS)
			{
				// Verify that the lock value was programmed
				if (newLock == lock)
				{
					status = SET_SUCCESS;
				}
			}
		}
	}
	// Lock all is not checked
	else
	{
		status = SET_SUCCESS;
	}

	return status;
}

/////////////////////////////////////////////////////////////////////////////
// CSetIDsDlg Class - Validation Methods
/////////////////////////////////////////////////////////////////////////////

// Validate a CEdit string length
BOOL CSetIDsDlg::ValidateStringLength(int strlen, int maxStrlen, CEdit* pEdit)
{
	BOOL validated = TRUE;

	// Check string length
	if (strlen > maxStrlen)
	{
		// Indicate invalid length to user
		CString msg;
		msg.Format(_T("Maximum string length is:\r\n%d\r\n\r\nSpecified string length is:\r\n%d"), maxStrlen, strlen);
		MessageBox(msg, _T("Validation Error"));

		// Select the invalid string
		pEdit->SetFocus();
		pEdit->SetSel(0, -1);

		validated = FALSE;
	}

	return validated;
}

// Perform additional data entry validation
// based on the part number feature set
BOOL CSetIDsDlg::ValidateFields()
{
	BOOL validated = TRUE;

	CString msg;

	// Validate manufacturer string length
	if (IsDlgButtonChecked(IDC_CHECK_MANUFACTURER) &&
		!ValidateStringLength(m_manufacturer.GetLength(), HID_UART_MFG_STRLEN, (CEdit*)GetDlgItem(IDC_EDIT_MANUFACTURER)))
	{
		validated = FALSE;
	}
	// Validate product string length
	else if (IsDlgButtonChecked(IDC_CHECK_PRODUCT) &&
		!ValidateStringLength(m_product.GetLength(), HID_UART_PRODUCT_STRLEN, (CEdit*)GetDlgItem(IDC_EDIT_PRODUCT)))
	{
		validated = FALSE;
	}
	// Validate serial string length
	else if (IsDlgButtonChecked(IDC_CHECK_SERIAL) &&
		!ValidateStringLength(m_serial.GetLength(), HID_UART_SERIAL_STRLEN, (CEdit*)GetDlgItem(IDC_EDIT_SERIAL)))
	{
		validated = FALSE;
	}

	return validated;
}
