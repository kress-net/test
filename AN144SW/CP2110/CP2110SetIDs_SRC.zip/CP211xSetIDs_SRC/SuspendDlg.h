#pragma once


// CSuspendDlg dialog

class CSuspendDlg : public CDialog
{
	DECLARE_DYNAMIC(CSuspendDlg)

public:
	CSuspendDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CSuspendDlg();

	WORD m_suspendMode;
	WORD m_suspendValue;

// Dialog Data
	enum { IDD = IDD_SUSPEND_DIALOG };

protected:
	void CheckMode(int nID);
	void CheckValue(int nID);

	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedCheckMode();
	afx_msg void OnBnClickedCheckValue();
	virtual BOOL OnInitDialog();
};
