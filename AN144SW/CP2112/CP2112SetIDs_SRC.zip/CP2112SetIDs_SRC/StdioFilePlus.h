#pragma once

/////////////////////////////////////////////////////////////////////////////
// CStdioFilePlus Class
/////////////////////////////////////////////////////////////////////////////

class CStdioFilePlus :	public CStdioFile
{
// Constructor/Destructor
public:
	CStdioFilePlus();
	~CStdioFilePlus();
	
// Public Methods
public:
	void WriteDecimal(UINT value);
	BOOL ReadDecimal(UINT& value);

// Overrides
public:
	virtual void WriteString(LPCTSTR lpsz);

// Protected Methods
protected:
	BOOL StringToDecimal(CString str, UINT& value);
};
