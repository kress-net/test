//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SetIDs.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SETIDS_DIALOG               102
#define IDS_CAPTION                     102
#define IDR_MAINFRAME                   128
#define IDR_MENU_SETIDS                 129
#define IDC_COMBO_DEV_LIST              1000
#define IDC_STATIC_LIBRARY_VERSION      1001
#define IDC_STATIC_HID_LIBRARY_VERSION  1002
#define IDC_BUTTON_PROGRAM              1003
#define IDC_EDIT_VID                    1004
#define IDC_EDIT_PID                    1005
#define IDC_CHECK_VID                   1006
#define IDC_CHECK_PID                   1007
#define IDC_EDIT_POWER                  1008
#define IDC_CHECK_POWER                 1009
#define IDC_CHECK_POWER_MODE            1010
#define IDC_CHECK_RELEASE_VERSION       1013
#define IDC_EDIT_RELEASE_VERSION_MSB    1014
#define IDC_EDIT_RELEASE_VERSION_LSB    1015
#define IDC_EDIT_PART_NUMBER            1019
#define IDC_EDIT_VERSION                1022
#define IDC_CHECK_LOCK_ALL              1023
#define IDC_EDIT_MANUFACTURER           1024
#define IDC_CHECK_MANUFACTURER          1025
#define IDC_EDIT_PRODUCT                1026
#define IDC_CHECK_PRODUCT               1027
#define IDC_EDIT_SERIAL                 1028
#define IDC_CHECK_SERIAL                1029
#define IDC_EDIT_POWER_MA               1048
#define IDC_STATIC_POWER                1072
#define IDC_BUTTON_GET_CUSTOMIZATION    1074
#define IDC_BUTTON_RESET                1075
#define IDC_STATIC_SMBUS_LIBRARY_VERSION 1084
#define IDC_RADIO_POWER_MODE_0          1097
#define IDC_RADIO_POWER_MODE_1          1098
#define IDC_RADIO_POWER_MODE_2          1099
#define ID_FILE_EXIT                    32771
#define ID_FILE_OPEN32772               32772
#define ID_FILE_SAVE32773               32773
#define ID_HELP_ABOUT                   32774
#define ID_FILE_SAVEAS                  32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1100
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
