/////////////////////////////////////////////////////////////////////////////
// SetIDsDlg.h : header file
/////////////////////////////////////////////////////////////////////////////

#pragma once

/////////////////////////////////////////////////////////////////////////////
// Includes
/////////////////////////////////////////////////////////////////////////////

#include "SLABCP2112.h"
#include "afxwin.h"
#include "StdioFilePlus.h"
#include <dbt.h>

/////////////////////////////////////////////////////////////////////////////
// Definitions
/////////////////////////////////////////////////////////////////////////////

// Set VID/PID filter values
// Settings these values to nonzero will
// display only devices with matching VID/PID
#define VID								0
#define PID								0

#define SAVE_STR_VID					_T("VID")
#define SAVE_STR_PID					_T("PID")
#define SAVE_STR_POWER					_T("Power")
#define SAVE_STR_POWER_MODE				_T("Power Mode")
#define SAVE_STR_RELEASE_VERSION		_T("Release Version")
#define SAVE_STR_MANUFACTURER			_T("Manufacturer")
#define SAVE_STR_PRODUCT				_T("Product")
#define SAVE_STR_SERIAL					_T("Serial")
#define SAVE_STR_LOCK_ALL				_T("Lock All")

/////////////////////////////////////////////////////////////////////////////
// Enumerations
/////////////////////////////////////////////////////////////////////////////

enum SET_STATUS {SET_SUCCESS, SET_FAIL, SET_VERIFY_FAIL};

/////////////////////////////////////////////////////////////////////////////
// CSetIDsDlg dialog
/////////////////////////////////////////////////////////////////////////////

class CSetIDsDlg : public CDialog
{
// Construction
public:
	CSetIDsDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_SETIDS_DIALOG };

	protected:
	void CustomDataExchange(CDataExchange* pDX);
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

// Control Members
protected:
	CComboBox m_comboDeviceList;

// Implementation
protected:
	HICON				m_hBigIcon;
	HICON				m_hSmallIcon;
	HDEVNOTIFY			m_hNotifyDevNode;
	CString				m_filename;
	HID_SMBUS_DEVICE	m_hidSmbus;

	void InitializeDialog();
	void InitCaption();

	void RegisterDeviceChange();
	void UnregisterDeviceChange();

	void UpdateCaption(CString saveFilename);
	void UpdateDeviceList();
	void UpdateLockState();
	void UpdateLockState_Clear();
	void UpdateCheckState();

	BOOL ConnectToSelected();
	BOOL DisconnectFromSelected();

	void Reset();

	void GetCustomization();
	void GetCustomization_Smbus();
	void GetCustomization_Clear();

	void SetCustomization();
	void SetCustomization_Smbus();

	BOOL Save(CString filename);
	BOOL LoadFieldValues(BOOL& successOneShot, CStdioFilePlus& file, CString fieldName, UINT* decimalValues, int numDecimalValues, CString* stringValues, int numStringValues);
	BOOL Load(CString filename);

// Programming Methods
protected:
	SET_STATUS ProgramUsbConfig();
	SET_STATUS ProgramManufacturerString();
	SET_STATUS ProgramProductString();
	SET_STATUS ProgramSerialString();
	SET_STATUS ProgramLockAll();

// Validation Methods
protected:
	BOOL ValidateFields();
	BOOL ValidateStringLength(int strlen, int maxStrlen, CEdit* pEdit);

// Generated message map functions
protected:
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg BOOL OnDeviceChange(UINT nEventType, DWORD_PTR dwData);
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnClose();
	afx_msg void OnHelpAbout();
	afx_msg void OnFileOpen();
	afx_msg void OnFileSave();
	afx_msg void OnFileSaveas();
	afx_msg void OnFileExit();
	afx_msg void OnEnChangeEditPower();
	afx_msg void OnBnClickedButtonGetCustomization();
	afx_msg void OnBnClickedButtonReset();
	afx_msg void OnCbnSelchangeComboDevList();
	afx_msg void OnCbnDropdownComboDevList();
	afx_msg void OnCbnCloseupComboDevList();
	afx_msg void OnBnClickedButtonProgram();
	afx_msg void OnBnClickedCheckBox();

// Control Variables
protected:
	CString		m_partNumberString;
	BYTE		m_version;
	WORD		m_vid;
	WORD		m_pid;
	BYTE		m_power;
	int			m_powerMode;
	BYTE		m_releaseVersionMsb;
	BYTE		m_releaseVersionLsb;
	CString		m_manufacturer;
	CString		m_product;
	CString		m_serial;
};
