/////////////////////////////////////////////////////////////////////////////
// Includes
/////////////////////////////////////////////////////////////////////////////

#include "StdAfx.h"
#include "StdioFilePlus.h"

/////////////////////////////////////////////////////////////////////////////
// CStdioFilePlus - Constructor/Destructor
/////////////////////////////////////////////////////////////////////////////

CStdioFilePlus::CStdioFilePlus()
{
}

CStdioFilePlus::~CStdioFilePlus()
{
}

/////////////////////////////////////////////////////////////////////////////
// CStdioFilePlus - Public Methods
/////////////////////////////////////////////////////////////////////////////

void CStdioFilePlus::WriteDecimal(UINT value)
{
	CString str;
	str.Format(_T("%u"), value);

	WriteString(str);
}

BOOL CStdioFilePlus::ReadDecimal(UINT& value)
{
	BOOL retVal = FALSE;
	CString str;
	UINT readValue;

	if (ReadString(str) && StringToDecimal(str, readValue))
	{
		value = readValue;
		retVal = TRUE;
	}

	return retVal;
}

void CStdioFilePlus::WriteString(LPCTSTR lpsz)
{
	CStdioFile::WriteString(CString(lpsz) + CString(_T("\n")));
}

/////////////////////////////////////////////////////////////////////////////
// CStdioFilePlus - Protected Methods
/////////////////////////////////////////////////////////////////////////////

BOOL CStdioFilePlus::StringToDecimal(CString str, UINT& value)
{
	BOOL retVal = FALSE;

	const TCHAR*	begin		= str;
	TCHAR*			end			= NULL;
	UINT			convert;

	convert = _tcstoul(begin, &end, 10);

	if (end-begin == str.GetLength())
	{
		value	= convert;
		retVal	= TRUE;
	}

	return retVal;
}
