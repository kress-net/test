/////////////////////////////////////////////////////////////////////////////
// SetIDsDlg.cpp : implementation file
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
// Includes
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SetIDs.h"
#include "SetIDsDlg.h"
#include "CustomDDX.h"
#include <vector>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
// Namespaces
/////////////////////////////////////////////////////////////////////////////

using namespace std;

/////////////////////////////////////////////////////////////////////////////
// Linker library inputs
/////////////////////////////////////////////////////////////////////////////

#pragma comment(lib, "SLABHIDtoSMBus.lib")

/////////////////////////////////////////////////////////////////////////////
// Static Global Variables
/////////////////////////////////////////////////////////////////////////////

struct UnlistedDevice
{
	WORD vid;
	WORD pid;
};

// Devices with these VID/PID combinations
// will not be listed in the device list
static UnlistedDevice UnlistedDevices[] = 
{
	{0x10C4, 0x8044},	// USB Debug Adapter
	{0x10C4, 0x8253}	// ToolStick
};

/////////////////////////////////////////////////////////////////////////////
// Static Function Prototypes
/////////////////////////////////////////////////////////////////////////////

// Return TRUE if the specified VID/PID should be displayed in the device list
// Otherwise return FALSE
BOOL ShouldDeviceBeListed(WORD vid, WORD pid);

/////////////////////////////////////////////////////////////////////////////
// Static Functions
/////////////////////////////////////////////////////////////////////////////

// Return TRUE if the specified VID/PID should be displayed in the device list
// Otherwise return FALSE
BOOL ShouldDeviceBeListed(WORD vid, WORD pid)
{
	BOOL listed = TRUE;

	// Search through all unlisted VID/PID pairs
	for (int i = 0; i < sizeof(UnlistedDevices)/sizeof(UnlistedDevices[0]); i++)
	{
		// Found a match
		if (vid == UnlistedDevices[i].vid &&
			pid == UnlistedDevices[i].pid)
		{
			listed = FALSE;
			break;
		}
	}

	return listed;
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About
/////////////////////////////////////////////////////////////////////////////

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()

BOOL CAboutDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	CString libStr;

	BYTE major;
	BYTE minor;
	BOOL release;

	if (HidSmbus_GetLibraryVersion(&major, &minor, &release) == HID_SMBUS_SUCCESS)
	{
		libStr.Format(_T("%u.%u (%s)"), major, minor, (release) ? _T("Release") : _T("Debug"));
		SetDlgItemText(IDC_STATIC_SMBUS_LIBRARY_VERSION, libStr);
	}

	if (HidSmbus_GetHidLibraryVersion(&major, &minor, &release) == HID_SMBUS_SUCCESS)
	{
		libStr.Format(_T("%u.%u (%s)"), major, minor, (release) ? _T("Release") : _T("Debug"));
		SetDlgItemText(IDC_STATIC_HID_LIBRARY_VERSION, libStr);
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

/////////////////////////////////////////////////////////////////////////////
// CSetIDsDlg dialog
/////////////////////////////////////////////////////////////////////////////

CSetIDsDlg::CSetIDsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSetIDsDlg::IDD, pParent)
	, m_partNumberString(_T(""))
	, m_version(0)
	, m_vid(0)
	, m_pid(0)
	, m_power(0)
	, m_powerMode(0)
	, m_releaseVersionMsb(0)
	, m_releaseVersionLsb(0)
	, m_manufacturer(_T(""))
	, m_product(_T(""))
	, m_serial(_T(""))
{
	m_hBigIcon		= AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_hSmallIcon	= (HICON)LoadImage(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME), IMAGE_ICON, 16, 16, 0);
	m_hidSmbus		= NULL;
}

void CSetIDsDlg::CustomDataExchange(CDataExchange* pDX)
{
	// Power is a 1-byte decimal value in the
	// range [0, HID_SMBUS_BUS_POWER_MAX/2]
	DDX_TextPlus(pDX, IDC_EDIT_POWER, m_power);
	DDV_MinMaxUInt(pDX, m_power, 0, HID_SMBUS_BUS_POWER_MAX);

	// Release Version MSB is a 1-byte decimal value
	DDX_TextPlus(pDX, IDC_EDIT_RELEASE_VERSION_MSB, m_releaseVersionMsb);

	// Release Version LSB is a 1-byte decimal value
	DDX_TextPlus(pDX, IDC_EDIT_RELEASE_VERSION_LSB, m_releaseVersionLsb);

	// VID is a 2-byte hex value
	DDX_TextHex(pDX, IDC_EDIT_VID, m_vid);
	DDV_MaxCharsHex(pDX, m_vid);

	// PID is a 2-byte hex value
	DDX_TextHex(pDX, IDC_EDIT_PID, m_pid);
	DDV_MaxCharsHex(pDX, m_pid);

	if (!pDX->m_bSaveAndValidate)
	{
		// Update power edit box in mA
		OnEnChangeEditPower();
	}
}

void CSetIDsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	DDX_Control(pDX, IDC_COMBO_DEV_LIST, m_comboDeviceList);
	DDX_Text(pDX, IDC_EDIT_PART_NUMBER, m_partNumberString);
	DDX_Text(pDX, IDC_EDIT_VERSION, m_version);
	DDX_Radio(pDX, IDC_RADIO_POWER_MODE_0, m_powerMode);
	DDX_Text(pDX, IDC_EDIT_MANUFACTURER, m_manufacturer);
	DDX_Text(pDX, IDC_EDIT_PRODUCT, m_product);
	DDX_Text(pDX, IDC_EDIT_SERIAL, m_serial);

	// Call custom DDX and DDV functions from the CustomDDX module
	CustomDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CSetIDsDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_DEVICECHANGE()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDOK, &CSetIDsDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CSetIDsDlg::OnBnClickedCancel)
	ON_WM_CLOSE()
	ON_COMMAND(ID_HELP_ABOUT, &CSetIDsDlg::OnHelpAbout)
	ON_COMMAND(ID_FILE_OPEN, &CSetIDsDlg::OnFileOpen)
	ON_COMMAND(ID_FILE_SAVE, &CSetIDsDlg::OnFileSave)
	ON_COMMAND(ID_FILE_EXIT, &CSetIDsDlg::OnFileExit)
	ON_CBN_SELCHANGE(IDC_COMBO_DEV_LIST, &CSetIDsDlg::OnCbnSelchangeComboDevList)
	ON_CBN_DROPDOWN(IDC_COMBO_DEV_LIST, &CSetIDsDlg::OnCbnDropdownComboDevList)
	ON_CBN_CLOSEUP(IDC_COMBO_DEV_LIST, &CSetIDsDlg::OnCbnCloseupComboDevList)
	ON_BN_CLICKED(IDC_BUTTON_PROGRAM, &CSetIDsDlg::OnBnClickedButtonProgram)
	ON_BN_CLICKED(IDC_CHECK_VID, &CSetIDsDlg::OnBnClickedCheckBox)
	ON_BN_CLICKED(IDC_CHECK_PID, &CSetIDsDlg::OnBnClickedCheckBox)
	ON_BN_CLICKED(IDC_CHECK_POWER, &CSetIDsDlg::OnBnClickedCheckBox)
	ON_BN_CLICKED(IDC_CHECK_POWER_MODE, &CSetIDsDlg::OnBnClickedCheckBox)
	ON_BN_CLICKED(IDC_CHECK_RELEASE_VERSION, &CSetIDsDlg::OnBnClickedCheckBox)
	ON_BN_CLICKED(IDC_CHECK_MANUFACTURER, &CSetIDsDlg::OnBnClickedCheckBox)
	ON_BN_CLICKED(IDC_CHECK_PRODUCT, &CSetIDsDlg::OnBnClickedCheckBox)
	ON_BN_CLICKED(IDC_CHECK_SERIAL, &CSetIDsDlg::OnBnClickedCheckBox)
	ON_COMMAND(ID_FILE_SAVEAS, &CSetIDsDlg::OnFileSaveas)
	ON_EN_CHANGE(IDC_EDIT_POWER, &CSetIDsDlg::OnEnChangeEditPower)
	ON_BN_CLICKED(IDC_BUTTON_GET_CUSTOMIZATION, &CSetIDsDlg::OnBnClickedButtonGetCustomization)
	ON_BN_CLICKED(IDC_BUTTON_RESET, &CSetIDsDlg::OnBnClickedButtonReset)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSetIDsDlg - Message Handlers
/////////////////////////////////////////////////////////////////////////////

BOOL CSetIDsDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hBigIcon, TRUE);			// Set big icon
	SetIcon(m_hSmallIcon, FALSE);		// Set small icon

	InitializeDialog();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSetIDsDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSetIDsDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hBigIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSetIDsDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hBigIcon);
}

// Handle device change messages (ie a device is added or removed)
// - If an HID device is connected, then add the device to the device list
// - If the device we were connected to was removed, then disconnect from the device
BOOL CSetIDsDlg::OnDeviceChange(UINT nEventType, DWORD_PTR dwData)
{
	// Device has been removed
	if (nEventType == DBT_DEVICEREMOVECOMPLETE ||
		nEventType == DBT_DEVICEARRIVAL)
	{
		if (dwData)
		{
			PDEV_BROADCAST_HDR pHdr = (PDEV_BROADCAST_HDR)dwData;

			if (pHdr->dbch_devicetype == DBT_DEVTYP_DEVICEINTERFACE)
			{
				PDEV_BROADCAST_DEVICEINTERFACE pDevInf = (PDEV_BROADCAST_DEVICEINTERFACE)pHdr;

				// I.E. "\\?\hid#vid_10c4&pid_81ba..."
				CString deviceStr = pDevInf->dbcc_name;

				if (nEventType == DBT_DEVICEREMOVECOMPLETE)
				{
					HID_SMBUS_DEVICE_STR smbusDeviceString;

					if (HidSmbus_GetOpenedString(m_hidSmbus, smbusDeviceString, HID_SMBUS_GET_PATH_STR) == HID_SMBUS_SUCCESS)
					{
						// Our device was removed
						if (deviceStr.CompareNoCase(CString(smbusDeviceString)) == 0)
						{
							// Close the device
							DisconnectFromSelected();
						}
					}
				}

				UpdateDeviceList();
			}
		}
	}

	return TRUE;
}

void CSetIDsDlg::OnBnClickedOk()
{
	// Prevent pressing enter from closing the dialog
}

void CSetIDsDlg::OnBnClickedCancel()
{
	// Prevent pressing escape from closing the dialog
}

void CSetIDsDlg::OnClose()
{
	// Override using OnCancel() so that
	// closing the dialog will work
	//
	// Don't use OnOK() because it forces control data
	// to be valid before you can close the dialog
	CDialog::OnCancel();
}

void CSetIDsDlg::OnFileOpen()
{
	if (UpdateData(TRUE))
	{
		CFileDialog openDlg(TRUE, 0, 0, OFN_HIDEREADONLY | OFN_ENABLESIZING, _T("CP2112 Set IDs Files (*.txt)|*.txt|All Files (*.*)|*.*||"));

		if (openDlg.DoModal() == IDOK)
		{
			CString path = openDlg.GetPathName();

			if (Load(path))
			{
				m_filename = path;
				UpdateCaption(m_filename);
			}
			else
			{
				CString msg;
				msg.Format(_T("Failed to load:\r\n%s"), path);
				MessageBox(msg, _T("Load Error"));
			}
		}
	}
}

void CSetIDsDlg::OnFileSave()
{
	if (UpdateData(TRUE))
	{
		if (m_filename.IsEmpty())
		{
			OnFileSaveas();
		}
		else
		{
			if (!Save(m_filename))
			{
				CString msg;
				msg.Format(_T("Failed to save:\r\n%s"), m_filename);
				MessageBox(msg, _T("Save Error"));
			}
		}
	}
}

void CSetIDsDlg::OnFileSaveas()
{
	if (UpdateData(TRUE))
	{
		CString defFname = _T("Custom.txt");

		if (!m_filename.IsEmpty())
		{
			defFname = m_filename;
		}

		CFileDialog saveDlg(FALSE, _T("txt"), defFname, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_ENABLESIZING, _T("CP2112 Set IDs Files (*.txt)|*.txt|All Files (*.*)|*.*||"));

		if (saveDlg.DoModal() == IDOK)
		{
			CString path = saveDlg.GetPathName();

			if (Save(path))
			{
				m_filename = path;
				UpdateCaption(m_filename);
			}
			else
			{
				CString msg;
				msg.Format(_T("Failed to save:\r\n%s"), path);
				MessageBox(msg, _T("Save Error"));
			}
		}
	}
}

void CSetIDsDlg::OnFileExit()
{
	OnClose();
}

void CSetIDsDlg::OnHelpAbout()
{
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
}

// Convert the power decimal value to milliamps
void CSetIDsDlg::OnEnChangeEditPower()
{
	CString power;
	GetDlgItemText(IDC_EDIT_POWER, power);

	UINT powerValue = _tcstoul(power, NULL, 10);

	CString power_mA;

	if (powerValue >= 0 && powerValue <= 250)
	{
		power_mA.Format(_T("%u"), powerValue * 2);
	}
	else
	{
		power_mA = _T("Invalid");
	}

	SetDlgItemText(IDC_EDIT_POWER_MA, power_mA);
}

void CSetIDsDlg::OnBnClickedButtonGetCustomization()
{
	GetCustomization();
}

void CSetIDsDlg::OnBnClickedButtonReset()
{
	// Send a command to the device to reset and
	// re-enumerate
	Reset();
}

void CSetIDsDlg::OnCbnSelchangeComboDevList()
{
	GetCustomization();
}

void CSetIDsDlg::OnCbnDropdownComboDevList()
{
	UpdateDeviceList();
}

void CSetIDsDlg::OnCbnCloseupComboDevList()
{
	BOOL		found	= FALSE;
	int			sel;
	CString		selText;

	// Check if the selected device has been removed or is in
	// use by another application

	sel = m_comboDeviceList.GetCurSel();

	if (sel != CB_ERR)
	{
		m_comboDeviceList.GetLBText(sel, selText);

		HID_SMBUS_DEVICE_STR	deviceString;
		DWORD					numDevices;

		// Search all HID devices for the selected device based on device path string
		if (HidSmbus_GetNumDevices(&numDevices, VID, PID) == HID_SMBUS_SUCCESS)
		{
			for (DWORD i = 0; i < numDevices; i++)
			{
				if (HidSmbus_GetString(i, VID, PID, deviceString, HID_SMBUS_GET_PATH_STR) == HID_SMBUS_SUCCESS)
				{
					if (selText.CompareNoCase(CString(deviceString)) == 0)
					{
						found = TRUE;
						break;
					}
				}
			}
		}
	}

	// Update the device list if the selected device is not availabled
	if (!found)
	{
		UpdateDeviceList();
	}
}

void CSetIDsDlg::OnBnClickedButtonProgram()
{
	SetCustomization();
}

void CSetIDsDlg::OnBnClickedCheckBox()
{
	UpdateCheckState();
}

/////////////////////////////////////////////////////////////////////////////
// CSetIDsDlg - Protected Methods
/////////////////////////////////////////////////////////////////////////////

void CSetIDsDlg::InitializeDialog()
{
	InitCaption();
	UpdateDeviceList();
	RegisterDeviceChange();
}

void CSetIDsDlg::InitCaption()
{
	CString caption;
	caption.LoadString(IDS_CAPTION);
	SetWindowText(caption);
}

// Register for device change notification for USB HID devices
// OnDeviceChange() will handle device arrival and removal
void CSetIDsDlg::RegisterDeviceChange()
{
	DEV_BROADCAST_DEVICEINTERFACE devIF = {0};

	devIF.dbcc_size			= sizeof(devIF);    
	devIF.dbcc_devicetype	= DBT_DEVTYP_DEVICEINTERFACE;    
	
	HidSmbus_GetHidGuid(&devIF.dbcc_classguid);
	
	m_hNotifyDevNode = RegisterDeviceNotification(GetSafeHwnd(), &devIF, DEVICE_NOTIFY_WINDOW_HANDLE);
}

// Unregister for device change notification for USB HID devices
void CSetIDsDlg::UnregisterDeviceChange()
{
	if (m_hNotifyDevNode)
	{
		UnregisterDeviceNotification(m_hNotifyDevNode);
		m_hNotifyDevNode = NULL;
	}
}

// Append save filename to the window caption
void CSetIDsDlg::UpdateCaption(CString saveFilename)
{
	TCHAR drive[_MAX_DRIVE];
	TCHAR dir[_MAX_DIR];
	TCHAR fname[_MAX_FNAME];
	TCHAR ext[_MAX_EXT];

	_tsplitpath_s(saveFilename, drive, _MAX_DRIVE, dir, _MAX_DIR, fname, _MAX_FNAME, ext, _MAX_EXT);

	CString caption;
	caption.LoadString(IDS_CAPTION);
	caption += _T(" - ");
	caption += fname;
	caption += ext;
	SetWindowText(caption);
}

// Populate the device list combo box with connected device path strings
// - Save previous device path string selection
// - Fill the device list with connected device path strings
// - Restore previous device selection
void CSetIDsDlg::UpdateDeviceList()
{
	// Only update the combo list when the drop down list is closed
	if (!m_comboDeviceList.GetDroppedState())
	{
		int			sel;
		CString		selText;

		// Save previous device path string selection
		sel = m_comboDeviceList.GetCurSel();

		if (sel != CB_ERR)
		{
			m_comboDeviceList.GetLBText(sel, selText);
		}

		DWORD					numDevices;
		HID_SMBUS_DEVICE_STR	smbusDeviceString;

		// Remove all devices from the device list
		m_comboDeviceList.ResetContent();

		// Fill the device path list for CP2112 devices
		// If VID/PID are both 0, then all HID devices will be listed
		if (HidSmbus_GetNumDevices(&numDevices, VID, PID) == HID_SMBUS_SUCCESS)
		{
			for (DWORD i = 0; i < numDevices; i++)
			{
				WORD vid;
				WORD pid;
				WORD releaseNumber;

				// Get the device VID, PID, and release number
				if (HidSmbus_GetAttributes(i, VID, PID, &vid, &pid, &releaseNumber) == HID_SMBUS_SUCCESS)
				{
					// Check to see if the current device should be listed
					if (ShouldDeviceBeListed(vid, pid))
					{
						if (HidSmbus_GetString(i, VID, PID, smbusDeviceString, HID_SMBUS_GET_PATH_STR) == HID_SMBUS_SUCCESS)
						{
							m_comboDeviceList.AddString(CString(smbusDeviceString));
						}
					}
				}
			}
		}

		// Restore previous device selection
		sel = m_comboDeviceList.FindStringExact(-1, selText);

		// If previous device was removed
		if (m_comboDeviceList.SetCurSel(sel) == CB_ERR)
		{
			// Then select the first device in the list
			m_comboDeviceList.SetCurSel(0);
		}

		// Update customization when a device is selected
		GetCustomization();
	}
}

// Enable/disable customization fields
// based on the lock value
void CSetIDsDlg::UpdateLockState()
{
	BYTE lock = 0x00;

	HidSmbus_GetLock(m_hidSmbus, &lock);

	// Uncheck the program field checkbox if the field has already been programmed/locked
	if (!(lock & HID_SMBUS_LOCK_VID))				CheckDlgButton(IDC_CHECK_VID,				FALSE);
	if (!(lock & HID_SMBUS_LOCK_PID))				CheckDlgButton(IDC_CHECK_PID,				FALSE);
	if (!(lock & HID_SMBUS_LOCK_POWER))				CheckDlgButton(IDC_CHECK_POWER,				FALSE);
	if (!(lock & HID_SMBUS_LOCK_POWER_MODE))		CheckDlgButton(IDC_CHECK_POWER_MODE,		FALSE);
	if (!(lock & HID_SMBUS_LOCK_RELEASE_VERSION))	CheckDlgButton(IDC_CHECK_RELEASE_VERSION,	FALSE);
	if (!(lock & HID_SMBUS_LOCK_MFG_STR))			CheckDlgButton(IDC_CHECK_MANUFACTURER,		FALSE);
	if (!(lock & HID_SMBUS_LOCK_PRODUCT_STR))		CheckDlgButton(IDC_CHECK_PRODUCT,			FALSE);
	if (!(lock & HID_SMBUS_LOCK_SERIAL_STR))		CheckDlgButton(IDC_CHECK_SERIAL,			FALSE);

	// Enable the program field checkbox if the field hasn't already been locked
	// and vice versa
	GetDlgItem(IDC_CHECK_VID)->EnableWindow((lock & HID_SMBUS_LOCK_VID) != 0);
	GetDlgItem(IDC_CHECK_PID)->EnableWindow((lock & HID_SMBUS_LOCK_PID) != 0);
	GetDlgItem(IDC_CHECK_POWER)->EnableWindow((lock & HID_SMBUS_LOCK_POWER) != 0);
	GetDlgItem(IDC_CHECK_POWER_MODE)->EnableWindow((lock & HID_SMBUS_LOCK_POWER_MODE) != 0);
	GetDlgItem(IDC_CHECK_RELEASE_VERSION)->EnableWindow((lock & HID_SMBUS_LOCK_RELEASE_VERSION) != 0);
	GetDlgItem(IDC_CHECK_MANUFACTURER)->EnableWindow((lock & HID_SMBUS_LOCK_MFG_STR) != 0);
	GetDlgItem(IDC_CHECK_PRODUCT)->EnableWindow((lock & HID_SMBUS_LOCK_PRODUCT_STR) != 0);
	GetDlgItem(IDC_CHECK_SERIAL)->EnableWindow((lock & HID_SMBUS_LOCK_SERIAL_STR) != 0);

	// Uncheck and disable the lock all checkbox if all fields are already locked
	if (lock == 0x00)
	{
		CheckDlgButton(IDC_CHECK_LOCK_ALL, FALSE);
		GetDlgItem(IDC_CHECK_LOCK_ALL)->EnableWindow(FALSE);
	}
	else
	{
		GetDlgItem(IDC_CHECK_LOCK_ALL)->EnableWindow(TRUE);
	}
}

// Enable all customization fields
void CSetIDsDlg::UpdateLockState_Clear()
{
	GetDlgItem(IDC_CHECK_VID)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHECK_PID)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHECK_POWER)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHECK_POWER_MODE)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHECK_RELEASE_VERSION)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHECK_MANUFACTURER)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHECK_PRODUCT)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHECK_SERIAL)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHECK_LOCK_ALL)->EnableWindow(TRUE);
}

// Enable/disable customization fields if the
// corresponding program checkbox is checked/unchecked
void CSetIDsDlg::UpdateCheckState()
{
	GetDlgItem(IDC_EDIT_VID)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_VID));
	GetDlgItem(IDC_EDIT_PID)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_PID));
	GetDlgItem(IDC_EDIT_POWER)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_POWER));
	GetDlgItem(IDC_RADIO_POWER_MODE_0)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_POWER_MODE));
	GetDlgItem(IDC_RADIO_POWER_MODE_1)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_POWER_MODE));
	GetDlgItem(IDC_RADIO_POWER_MODE_2)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_POWER_MODE));
	GetDlgItem(IDC_EDIT_RELEASE_VERSION_MSB)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_RELEASE_VERSION));
	GetDlgItem(IDC_EDIT_RELEASE_VERSION_LSB)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_RELEASE_VERSION));
	GetDlgItem(IDC_EDIT_MANUFACTURER)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_MANUFACTURER));
	GetDlgItem(IDC_EDIT_PRODUCT)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_PRODUCT));
	GetDlgItem(IDC_EDIT_SERIAL)->EnableWindow(IsDlgButtonChecked(IDC_CHECK_SERIAL));
}

// Connect to an HID device with a device path that matches
// the selected device path in the device combobox
BOOL CSetIDsDlg::ConnectToSelected()
{
	DWORD	numDevices	= 0;
	BOOL	found		= FALSE;
	BOOL	connected	= FALSE;
	DWORD	deviceNum	= 0;

	CString					selectedPath;
	HID_SMBUS_DEVICE_STR	deviceString;

	// Get selected device path
	m_comboDeviceList.GetWindowText(selectedPath);

	// Make sure that a device is selected
	if (!selectedPath.IsEmpty())
	{
		// Search through all HID devices for a matching device path
		if (HidSmbus_GetNumDevices(&numDevices, NULL, NULL) == HID_SMBUS_SUCCESS)
		{
			for (DWORD i = 0; i < numDevices; i++)
			{
				// Get the device path
				if (HidSmbus_GetString(i, NULL, NULL, deviceString, HID_SMBUS_GET_PATH_STR) == HID_SMBUS_SUCCESS)
				{
					// Check if the path matches the selected device path
					if (selectedPath == deviceString)
					{
						deviceNum	= i;
						found		= TRUE;
						break;
					}
				}
			}
		}

		// Found a device with a matching path
		if (found)
		{
			// Connect to the matching device
			if (HidSmbus_Open(&m_hidSmbus, deviceNum, NULL, NULL) == HID_SMBUS_SUCCESS)
			{
				connected = TRUE;
			}
		}
	}

	return connected;
}

// Disconnect from the currently connected device
BOOL CSetIDsDlg::DisconnectFromSelected()
{
	BOOL disconnected = FALSE;

	HID_SMBUS_STATUS status = HidSmbus_Close(m_hidSmbus);
	m_hidSmbus = NULL;

	return disconnected;
}

// Reset the device
void CSetIDsDlg::Reset()
{
	CWaitCursor wait;

	if (ConnectToSelected())
	{
		// Send a command to the device to reset and
		// re-enumerate
		HID_SMBUS_STATUS status = HidSmbus_Reset(m_hidSmbus);

		DisconnectFromSelected();

		// Refresh the dialog with the newly programmed values
		GetCustomization();
	}
}

// Connect to selected device and retrieve
// current device customization fields
void CSetIDsDlg::GetCustomization()
{
	CWaitCursor wait;

	UpdateData(TRUE);

	if (ConnectToSelected())
	{
		GetCustomization_Smbus();

		UpdateData(FALSE);

		// Enable/disable customization fields
		// based on the lock value
		UpdateLockState();

		// Enable/disable customization fields if the
		// corresponding program checkbox is checked/unchecked
		UpdateCheckState();

		DisconnectFromSelected();
	}
	else
	{
		// Clear device customization fields
		GetCustomization_Clear();
		
		UpdateData(FALSE);

		// Enable all customization fields
		UpdateLockState_Clear();

		// Enable/disable customization fields if the
		// corresponding program checkbox is checked/unchecked
		UpdateCheckState();
	}
}

// Retrieve current device customization fields
void CSetIDsDlg::GetCustomization_Smbus()
{
	BYTE partNumber;
	BYTE version;
	
	WORD vid;
	WORD pid;
	BYTE power;
	BYTE powerMode;
	WORD releaseVersion;

	HID_SMBUS_CP2112_MFG_STR		manufacturingString;
	HID_SMBUS_CP2112_PRODUCT_STR	productString;
	HID_SMBUS_CP2112_SERIAL_STR		serialString;
	BYTE							strlen;

	// Update part number and version
	if (HidSmbus_GetPartNumber(m_hidSmbus, &partNumber, &version) == HID_SMBUS_SUCCESS)
	{
		switch (partNumber)
		{
		case HID_SMBUS_PART_CP2112:		m_partNumberString = _T("CP2112");	break;
		}

		m_version = version;
	}

	// Update Vendor ID, Product ID, power, power mode, release version, and flush buffers settings
	if (HidSmbus_GetUsbConfig(m_hidSmbus, &vid, &pid, &power, &powerMode, &releaseVersion) == HID_SMBUS_SUCCESS)
	{
		m_vid					= vid;
		m_pid					= pid;
		m_power					= power;
		m_powerMode				= powerMode;
		m_releaseVersionMsb		= (BYTE)(releaseVersion >> 8);
		m_releaseVersionLsb		= (BYTE)(releaseVersion);
	}

	// Update manufacturer string
	if (HidSmbus_GetManufacturingString(m_hidSmbus, manufacturingString, &strlen) == HID_SMBUS_SUCCESS)
	{
		m_manufacturer = CString(manufacturingString, strlen);
	}

	// Update product string
	if (HidSmbus_GetProductString(m_hidSmbus, productString, &strlen) == HID_SMBUS_SUCCESS)
	{
		m_product = CString(productString, strlen);
	}

	// Update serial string
	if (HidSmbus_GetSerialString(m_hidSmbus, serialString, &strlen) == HID_SMBUS_SUCCESS)
	{
		m_serial = CString(serialString, strlen);
	}
}

// Clear device customization fields
void CSetIDsDlg::GetCustomization_Clear()
{
	// Reset all dialog controls to default values

	m_partNumberString		= _T("");
	m_version				= 0;
	m_vid					= 0;
	m_pid					= 0;
	m_power					= 0;
	m_powerMode				= 0;
	m_releaseVersionMsb		= 0;
	m_releaseVersionLsb		= 0;
	m_manufacturer			= _T("");
	m_product				= _T("");
	m_serial				= _T("");
}

// Connect to selected device and program
// new device customization fields
void CSetIDsDlg::SetCustomization()
{
	CWaitCursor wait;

	if (UpdateData(TRUE))
	{
		CString selectedPath;

		// Get selected device path
		m_comboDeviceList.GetWindowText(selectedPath);
		
		if (!selectedPath.IsEmpty())
		{
			// Connect to the selected device
			if (ConnectToSelected())
			{
				BOOL valid = ValidateFields();

				if (valid)
				{
					SetCustomization_Smbus();
				}

				DisconnectFromSelected();

				if (valid)
				{
					// Refresh the dialog with the newly programmed values
					GetCustomization();
				}
			}
			else
			{
				CString msg;
				msg.Format(_T("Could not connect to %s"), selectedPath);
				MessageBox(msg, _T("Connection Error"));
			}
		}
	}
}

// Program selected device customization fields
void CSetIDsDlg::SetCustomization_Smbus()
{
	SET_STATUS status;

	// Program USB configuration
	if ((status = ProgramUsbConfig()) != SET_SUCCESS)
	{
		MessageBox(_T("Failed to program USB Configuration field(s)"), _T("Programming Error"));
	}
	// Program Manufacturer String
	else if ((status = ProgramManufacturerString()) != SET_SUCCESS)
	{
		MessageBox(_T("Failed to program manufacturer string field"), _T("Programming Error"));
	}
	// Program Product String
	else if ((status = ProgramProductString()) != SET_SUCCESS)
	{
		MessageBox(_T("Failed to program product string field"), _T("Programming Error"));
	}
	// Program Serial String
	else if ((status = ProgramSerialString()) != SET_SUCCESS)
	{
		MessageBox(_T("Failed to program serial string field"), _T("Programming Error"));
	}
	// Program Lock field
	else if ((status = ProgramLockAll()) != SET_SUCCESS)
	{
		MessageBox(_T("Failed to lock device customization"), _T("Programming Error"));
	}
	// All fields programmed successfully
	else
	{
		MessageBox(_T("All selected fields were programmed succcessfully"), _T("Success"));
	}
}

// Save settings to specified text file in
// plain text
BOOL CSetIDsDlg::Save(CString filename)
{
	BOOL retVal = FALSE;

	if (UpdateData(TRUE))
	{
		CStdioFilePlus file;

		if (file.Open(filename, CFile::modeWrite | CFile::modeCreate))
		{
			// Save USB configuration field state
			file.WriteString(SAVE_STR_VID);				file.WriteDecimal(IsDlgButtonChecked(IDC_CHECK_VID));				file.WriteDecimal(m_vid);
			file.WriteString(SAVE_STR_PID);				file.WriteDecimal(IsDlgButtonChecked(IDC_CHECK_PID));				file.WriteDecimal(m_pid);
			file.WriteString(SAVE_STR_POWER);			file.WriteDecimal(IsDlgButtonChecked(IDC_CHECK_POWER));				file.WriteDecimal(m_power);
			file.WriteString(SAVE_STR_POWER_MODE);		file.WriteDecimal(IsDlgButtonChecked(IDC_CHECK_POWER_MODE));		file.WriteDecimal(m_powerMode);
			file.WriteString(SAVE_STR_RELEASE_VERSION);	file.WriteDecimal(IsDlgButtonChecked(IDC_CHECK_RELEASE_VERSION));	file.WriteDecimal(MAKEWORD(m_releaseVersionLsb, m_releaseVersionMsb));

			// Save string descriptors
			file.WriteString(SAVE_STR_MANUFACTURER);	file.WriteDecimal(IsDlgButtonChecked(IDC_CHECK_MANUFACTURER));	file.WriteString(m_manufacturer);
			file.WriteString(SAVE_STR_PRODUCT);			file.WriteDecimal(IsDlgButtonChecked(IDC_CHECK_PRODUCT));		file.WriteString(m_product);
			file.WriteString(SAVE_STR_SERIAL);			file.WriteDecimal(IsDlgButtonChecked(IDC_CHECK_SERIAL));		file.WriteString(m_serial);

			// Save Lock All Checkbox
			file.WriteString(SAVE_STR_LOCK_ALL);		file.WriteDecimal(IsDlgButtonChecked(IDC_CHECK_LOCK_ALL));

			file.Close();

			retVal = TRUE;
		}
	}

	return retVal;
}

// Loads a customization field and the specified number of decimal and string values for the field
// Returns TRUE if the read string matches the field name and if all decimal and string values were read
//
// successOneShot - Used to determine the success of multiple calls to this function
//				    Caller must initially set this value to TRUE
//					Once a single call to this function fails, successOneShot will be
//					set to and remain FALSE until set to true again by the caller
BOOL CSetIDsDlg::LoadFieldValues(BOOL& successOneShot, CStdioFilePlus& file, CString fieldName, UINT* decimalValues, int numDecimalValues, CString* stringValues, int numStringValues)
{
	BOOL retVal = FALSE;

	UINT	decimalValue;
	CString	stringValue;

	// Verify that the next entry in the file
	// matches the field name
	if (file.ReadString(stringValue) && stringValue == fieldName)
	{
		BOOL readValues = TRUE;

		// Read specified number of decimal field values
		for (int i = 0; i < numDecimalValues; i++)
		{
			if (file.ReadDecimal(decimalValue))
			{
				decimalValues[i] = decimalValue;
			}
			else
			{
				readValues = FALSE;
			}
		}

		// Read specified number of string field values
		for (int i = 0; i < numStringValues; i++)
		{
			if (file.ReadString(stringValue))
			{
				stringValues[i] = stringValue;
			}
			else
			{
				readValues = FALSE;
			}
		}

		if (readValues)
		{
			retVal = TRUE;
		}
	}

	if (!retVal)
	{
		successOneShot = FALSE;
	}

	return retVal;
}

// Load settings from specified text file in
// plain text
BOOL CSetIDsDlg::Load(CString filename)
{
	BOOL retVal = FALSE;

	if (UpdateData(TRUE))
	{
		CStdioFilePlus file;

		if (file.Open(filename, CFile::modeRead))
		{
			BOOL		readSuccess	= TRUE;
			UINT		values[18];
			CString		strings[1];

			// Load USB configuration field state
			if (LoadFieldValues(readSuccess, file, SAVE_STR_VID, values, 2, NULL, 0))
			{
				CheckDlgButton(IDC_CHECK_VID, values[0]);
				m_vid = values[1];
			}
			if (LoadFieldValues(readSuccess, file, SAVE_STR_PID, values, 2, NULL, 0))
			{
				CheckDlgButton(IDC_CHECK_PID, values[0]);
				m_pid = values[1];
			}
			if (LoadFieldValues(readSuccess, file, SAVE_STR_POWER, values, 2, NULL, 0))
			{
				CheckDlgButton(IDC_CHECK_POWER, values[0]);
				m_power = values[1];
			}
			if (LoadFieldValues(readSuccess, file, SAVE_STR_POWER_MODE, values, 2, NULL, 0))
			{
				CheckDlgButton(IDC_CHECK_POWER_MODE, values[0]);
				m_powerMode = values[1];
			}
			if (LoadFieldValues(readSuccess, file, SAVE_STR_RELEASE_VERSION, values, 2, NULL, 0))
			{
				CheckDlgButton(IDC_CHECK_RELEASE_VERSION, values[0]);
				m_releaseVersionMsb = (BYTE)(values[1] >> 8);
				m_releaseVersionLsb = (BYTE)(values[1]);
			}

			// Load string descriptors
			if (LoadFieldValues(readSuccess, file, SAVE_STR_MANUFACTURER, values, 1, strings, 1))
			{
				CheckDlgButton(IDC_CHECK_MANUFACTURER, values[0]);
				m_manufacturer = strings[0];
			}
			if (LoadFieldValues(readSuccess, file, SAVE_STR_PRODUCT, values, 1, strings, 1))
			{
				CheckDlgButton(IDC_CHECK_PRODUCT, values[0]);
				m_product = strings[0];
			}
			if (LoadFieldValues(readSuccess, file, SAVE_STR_SERIAL, values, 1, strings, 1))
			{
				CheckDlgButton(IDC_CHECK_SERIAL, values[0]);
				m_serial = strings[0];
			}

			// Load Lock All Checkbox
			if (LoadFieldValues(readSuccess, file, SAVE_STR_LOCK_ALL, values, 1, NULL, 0))
			{
				CheckDlgButton(IDC_CHECK_LOCK_ALL, values[0]);
			}

			if (readSuccess)
			{
				retVal = TRUE;
			}

			file.Close();
			UpdateData(FALSE);

			// If a checkbox is disabled, this means that the field has been locked
			// Uncheck the checkbox
			if (!GetDlgItem(IDC_CHECK_VID)->IsWindowEnabled())					CheckDlgButton(IDC_CHECK_VID, FALSE);
			if (!GetDlgItem(IDC_CHECK_PID)->IsWindowEnabled())					CheckDlgButton(IDC_CHECK_PID, FALSE);
			if (!GetDlgItem(IDC_CHECK_POWER)->IsWindowEnabled())				CheckDlgButton(IDC_CHECK_POWER, FALSE);
			if (!GetDlgItem(IDC_CHECK_POWER_MODE)->IsWindowEnabled())			CheckDlgButton(IDC_CHECK_POWER_MODE, FALSE);
			if (!GetDlgItem(IDC_CHECK_RELEASE_VERSION)->IsWindowEnabled())		CheckDlgButton(IDC_CHECK_RELEASE_VERSION, FALSE);
			if (!GetDlgItem(IDC_CHECK_MANUFACTURER)->IsWindowEnabled())			CheckDlgButton(IDC_CHECK_MANUFACTURER, FALSE);
			if (!GetDlgItem(IDC_CHECK_PRODUCT)->IsWindowEnabled())				CheckDlgButton(IDC_CHECK_PRODUCT, FALSE);
			if (!GetDlgItem(IDC_CHECK_SERIAL)->IsWindowEnabled())				CheckDlgButton(IDC_CHECK_SERIAL, FALSE);
			if (!GetDlgItem(IDC_CHECK_LOCK_ALL)->IsWindowEnabled())				CheckDlgButton(IDC_CHECK_LOCK_ALL, FALSE);

			// Enable/disable customization fields if the
			// corresponding program checkbox is checked/unchecked
			UpdateCheckState();
		}
	}

	return retVal;
}

/////////////////////////////////////////////////////////////////////////////
// CSetIDsDlg - Programming Methods
/////////////////////////////////////////////////////////////////////////////

// Program and verify the usb configuration customization fields
SET_STATUS CSetIDsDlg::ProgramUsbConfig()
{
	SET_STATUS status = SET_FAIL;

	// Populate customization field values
	BYTE mask				= 0x00;
	WORD vid				= (WORD)m_vid;
	WORD pid				= (WORD)m_pid;
	BYTE power				= m_power;
	BYTE powerMode			= (BYTE)m_powerMode;
	WORD releaseVersion		= ((WORD)m_releaseVersionMsb << 8) | m_releaseVersionLsb;

	// Set program mask based on which checkboxes are checked
	if (IsDlgButtonChecked(IDC_CHECK_VID))					mask |= HID_SMBUS_SET_VID;
	if (IsDlgButtonChecked(IDC_CHECK_PID))					mask |= HID_SMBUS_SET_PID;
	if (IsDlgButtonChecked(IDC_CHECK_POWER))				mask |= HID_SMBUS_SET_POWER;
	if (IsDlgButtonChecked(IDC_CHECK_POWER_MODE))			mask |= HID_SMBUS_SET_POWER_MODE;
	if (IsDlgButtonChecked(IDC_CHECK_RELEASE_VERSION))		mask |= HID_SMBUS_SET_RELEASE_VERSION;

	// Fields were checked to be programmed
	if (mask != 0x00)
	{
		// Set customization field values
		if (HidSmbus_SetUsbConfig(m_hidSmbus, vid, pid, power, powerMode, releaseVersion, mask) == HID_SMBUS_SUCCESS)
		{
			WORD newVid;
			WORD newPid;
			BYTE newPower;
			BYTE newPowerMode;
			WORD newReleaseVersion;

			status = SET_VERIFY_FAIL;

			// Get customization field values
			if (HidSmbus_GetUsbConfig(m_hidSmbus, &newVid, &newPid, &newPower, &newPowerMode, &newReleaseVersion) == HID_SMBUS_SUCCESS)
			{
				// Verify that fields that were checked were programmed
				// successfully
				if (((!(mask & HID_SMBUS_SET_VID)) || (newVid == vid)) &&
					((!(mask & HID_SMBUS_SET_PID)) || (newPid == pid)) &&
					((!(mask & HID_SMBUS_SET_POWER)) || (newPower == power)) &&
					((!(mask & HID_SMBUS_SET_POWER_MODE)) || (newVid == vid)) &&
					((!(mask & HID_SMBUS_SET_RELEASE_VERSION)) || (newVid == vid)))
				{
					status = SET_SUCCESS;
				}
			}
		}
	}
	// No USB config fields were checked
	else
	{
		status = SET_SUCCESS;
	}

	return status;
}

// Program and verify the manufacturer string customization field
SET_STATUS CSetIDsDlg::ProgramManufacturerString()
{
	SET_STATUS status = SET_FAIL;

	// Manufacturer string is checked
	if (IsDlgButtonChecked(IDC_CHECK_MANUFACTURER))
	{
		HID_SMBUS_CP2112_MFG_STR	mfrString;
		BYTE						strlen = 0;

		strlen = m_manufacturer.GetLength();

		// Convert Unicode CString to
		// ASCII character array
		for (int i = 0; i < strlen; i++)
		{
			mfrString[i] = (char)m_manufacturer[i];
		}

		// Set manufacturer string
		if (HidSmbus_SetManufacturingString(m_hidSmbus, mfrString, strlen) == HID_SMBUS_SUCCESS)
		{
			HID_SMBUS_CP2112_MFG_STR	newMfrString;
			BYTE						newStrlen;

			status = SET_VERIFY_FAIL;

			// Get manufacturer string
			if (HidSmbus_GetManufacturingString(m_hidSmbus, newMfrString, &newStrlen) == HID_SMBUS_SUCCESS)
			{
				// Verify that the manufacturer string was programmed successfully
				if (newStrlen == strlen &&
					memcmp(newMfrString, mfrString, strlen) == 0)
				{
					status = SET_SUCCESS;
				}
			}
		}
	}
	// Manufacturer string is not checked
	else
	{
		status = SET_SUCCESS;
	}

	return status;
}

// Program and verify the product string customization field
SET_STATUS CSetIDsDlg::ProgramProductString()
{
	SET_STATUS status = SET_FAIL;

	// Product string is checked
	if (IsDlgButtonChecked(IDC_CHECK_PRODUCT))
	{
		HID_SMBUS_CP2112_PRODUCT_STR	productString;
		BYTE							strlen = 0;

		strlen = m_product.GetLength();

		// Convert Unicode CString to
		// ASCII character array
		for (int i = 0; i < strlen; i++)
		{
			productString[i] = (char)m_product[i];
		}

		// Set product string
		if (HidSmbus_SetProductString(m_hidSmbus, productString, strlen) == HID_SMBUS_SUCCESS)
		{
			HID_SMBUS_CP2112_PRODUCT_STR	newProductString;
			BYTE							newStrlen;

			status = SET_VERIFY_FAIL;

			// Get product string
			if (HidSmbus_GetProductString(m_hidSmbus, newProductString, &newStrlen) == HID_SMBUS_SUCCESS)
			{
				// Verify that the product string was programmed successfully
				if (newStrlen == strlen &&
					memcmp(newProductString, productString, strlen) == 0)
				{
					status = SET_SUCCESS;
				}
			}
		}
	}
	// Product string is not checked
	else
	{
		status = SET_SUCCESS;
	}

	return status;
}

// Program and verify the serial string customization field
SET_STATUS CSetIDsDlg::ProgramSerialString()
{
	SET_STATUS status = SET_FAIL;

	// Serial string is checked
	if (IsDlgButtonChecked(IDC_CHECK_SERIAL))
	{
		HID_SMBUS_CP2112_SERIAL_STR		serialString;
		BYTE							strlen = 0;

		strlen = m_serial.GetLength();

		// Convert Unicode CString to
		// ASCII character array
		for (int i = 0; i < strlen; i++)
		{
			serialString[i] = (char)m_serial[i];
		}

		// Set serial string
		if (HidSmbus_SetSerialString(m_hidSmbus, serialString, strlen) == HID_SMBUS_SUCCESS)
		{
			HID_SMBUS_CP2112_SERIAL_STR		newSerialString;
			BYTE							newStrlen;

			status = SET_VERIFY_FAIL;

			// Get serial string
			if (HidSmbus_GetSerialString(m_hidSmbus, newSerialString, &newStrlen) == HID_SMBUS_SUCCESS)
			{
				// Verify that the serial string was programmed successfully
				if (newStrlen == strlen &&
					memcmp(newSerialString, serialString, strlen) == 0)
				{
					status = SET_SUCCESS;
				}
			}
		}
	}
	// Serial string is not checked
	else
	{
		status = SET_SUCCESS;
	}

	return status;
}

// Program and verify the lock byte customization field
SET_STATUS CSetIDsDlg::ProgramLockAll()
{
	SET_STATUS status = SET_FAIL;

	// Lock all is checked
	if (IsDlgButtonChecked(IDC_CHECK_LOCK_ALL))
	{
		BYTE lock = 0x00;

		// Lock all customization fields
		if (HidSmbus_SetLock(m_hidSmbus, lock) == HID_SMBUS_SUCCESS)
		{
			BYTE newLock;

			status = SET_VERIFY_FAIL;

			// Get lock value
			if (HidSmbus_GetLock(m_hidSmbus, &newLock) == HID_SMBUS_SUCCESS)
			{
				// Verify that the lock value was programmed
				if (newLock == lock)
				{
					status = SET_SUCCESS;
				}
			}
		}
	}
	// Lock all is not checked
	else
	{
		status = SET_SUCCESS;
	}

	return status;
}

/////////////////////////////////////////////////////////////////////////////
// CSetIDsDlg Class - Validation Methods
/////////////////////////////////////////////////////////////////////////////

// Validate a CEdit string length
BOOL CSetIDsDlg::ValidateStringLength(int strlen, int maxStrlen, CEdit* pEdit)
{
	BOOL validated = TRUE;

	// Check string length
	if (strlen > maxStrlen)
	{
		// Indicate invalid length to user
		CString msg;
		msg.Format(_T("Maximum string length is:\r\n%d\r\n\r\nSpecified string length is:\r\n%d"), maxStrlen, strlen);
		MessageBox(msg, _T("Validation Error"));

		// Select the invalid string
		pEdit->SetFocus();
		pEdit->SetSel(0, -1);

		validated = FALSE;
	}

	return validated;
}

// Perform additional data entry validation
// based on the part number feature set
BOOL CSetIDsDlg::ValidateFields()
{
	BOOL validated = TRUE;

	CString msg;

	// Validate CP2112 string lengths

	// Validate manufacturer string length
	if (IsDlgButtonChecked(IDC_CHECK_MANUFACTURER) &&
		!ValidateStringLength(m_manufacturer.GetLength(), HID_SMBUS_CP2112_MFG_STRLEN, (CEdit*)GetDlgItem(IDC_EDIT_MANUFACTURER)))
	{
		validated = FALSE;
	}
	// Validate product string length
	else if (IsDlgButtonChecked(IDC_CHECK_PRODUCT) &&
		!ValidateStringLength(m_product.GetLength(), HID_SMBUS_CP2112_PRODUCT_STRLEN, (CEdit*)GetDlgItem(IDC_EDIT_PRODUCT)))
	{
		validated = FALSE;
	}
	// Validate serial string length
	else if (IsDlgButtonChecked(IDC_CHECK_SERIAL) &&
		!ValidateStringLength(m_serial.GetLength(), HID_SMBUS_CP2112_SERIAL_STRLEN, (CEdit*)GetDlgItem(IDC_EDIT_SERIAL)))
	{
		validated = FALSE;
	}

	return validated;
}
